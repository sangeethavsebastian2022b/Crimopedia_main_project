<?php
session_start();
if(isset($_SESSION['users_login'])){
include 'connect.php'; 
$usr = $_SESSION['users_login'];

$req_id=@$_GET['tid'];
$_SESSION['rid']=$req_id;
$coid=@$_GET['id'];
$_SESSION['logid']=$coid;
?>

<!doctype html>

<html class="no-js" lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Crimopedia </title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <link rel="stylesheet" href="vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
   table {
    border-collapse: collapse;
    width: 100%;
    color: #3C92B0;
  }
  
 td {
    text-align: center;
    padding: 10px;
  }
  th{
       text-align: left;
    padding: 20px;
  }
  
  tr:nth-child(odd){background-color:#f2f2f2}
  
  th { 
    background-color:rgb(94, 11, 80);
    color: white;
    width:300px;
  }
  
td {
    width: 950px;
    
}
.tdi{
    width:450px;
    
}
  .in{
    text-align: left;
    padding: 10px;
    width: 90%;
  }
  .frm
    {
      position:absolute;
      top:200px;
      left:500px;
      width:50%; 
      border-radius: 10px;
      background-color: white;
     
    }
    .tdi input:focus{
      outline: 6px;
      border-color: rgb(61, 185, 61);
  
  }
.error
{
 font-size:bold;
 color:red;
 text-transform: uppercase;
 text-align: center;
 font-size: 7px;
  
    
}  


.button1 {
    background-color:rgb(129, 30, 30);
    border-radius: 2px;
    border: none;
    color: white;
    padding: 12px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 20px;
    margin: 7px 2px;
    margin-top: 50px;
    cursor: pointer;
    font-family: sans-serif;
    margin-left: 200px;
}

.button2 {
  background-color:rgb(129, 30, 30);
  border-radius: 2px;
  border: none;
  color: white;
  padding: 12px 34px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  margin: 4px 2px;
  cursor: pointer;
  font-family: sans-serif;
}
</style>
    <script>		
function myFunction() 
{
  
        document.getElementById('btn')
        alert("Blocked!");
        document.getElementById('btn').prop('disabled',true);
}	            
</script>

<script>		
function myFunction1() 
{
  
        document.getElementById('btn')
        alert("UnBlocked!");
        document.getElementById('btn').prop('disabled',true);
}	            
</script>
</head>

<body>




    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="#">Crimopedia</a>
                <a class="navbar-brand hidden" href="./">F</a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="counsellordashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <div id="container">
                    
                    <li>
                        <a href="viewrequest.php"> <i class="menu-icon fa fa-folder"></i>View Request</a>
                    </li>
      
                   
                    
                    <li >
                        <a href="scheduledcounselling.php"> <i class="menu-icon fa fa-folder"></i>Schedules</a>
                    </li>
                   <!-- <li >
                        <a href="counsellingcomplete.php"> <i class="menu-icon fa fa-folder"></i>Complete Status</a>
                    </li>-->
                    <li >
                        <a href="viewcompletecounselling.php"> <i class="menu-icon fa fa-folder"></i>Complete Status</a>
                    </li>
                   
                   
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->


    <div id="right-panel" class="right-panel" style="background-image: url('images/324.jpg'); height: 100%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/324.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->
        <?php
       // $req_id=$_GET['tid'];
        $qwer="update counselling_request set status='1' where req_id='$req_id'";
        $result=mysqli_query($con,$qwer);

        ?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Schedule Form</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                   <!-- <div class="col-md-12">
                        <div class="card">
                           
                            <div class="card-body">-->
                                
                            <form action="scheduleconnection.php" method="POST" name="frm" id="form" class="frm" >
<div class="error"><p id="demo"></p></div>
<table width="100%" border="3" style="border-collapse:collapse;">
<tr>
<th><center><strong> Scheduling Date</strong></center></th>
<td class="tdi"><center><input type="date"  class ="in"  name="date" id="date" min="<?= date('Y-m-d');?>"></center></td>
</tr>
<tr>
<th><center><strong> Scheduling Time</strong></center></th>
<td class="tdi"><center><input type="time"  class ="in"  name="time" id="time"></center></td>
</tr>

<!--<?php 
$count = 1;
$req_id=$_GET['id'];
$id=$_SESSION['users_login'];
$query6 ="SELECT * FROM counselling_request where req_id ='$req_id'";  
$res1 = mysqli_query($con,$query6);
$ri=mysqli_fetch_array($res1);
?>
<?php 
$coid=$_GET['id'];
$id=$_SESSION['users_login'];
$query6 ="SELECT * FROM complaint_registration where cid ='$coid'";  
$res1 = mysqli_query($con,$query6);
$ri=mysqli_fetch_array($res1);
?>-->
 
</table>
<!--<a href="counsellingrequesting.php" class="button1" >Request</a>-->
<!--<input type="submit" value=submit name="submit">-->

<input type="text" name="tid" value="<?php echo $req_id; ?>" hidden/> 
<input type="text" name="tid" values="<?php echo $req_id;?>"hidden />

<center><input type="submit" value="Submit" name="submit"></center>
</form>

   </table>   

          


                  

                            </div>

                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->
       <!-- /#right-panel -->

    <!-- Right Panel -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>
<?php
}
?>

</body>

</html>


