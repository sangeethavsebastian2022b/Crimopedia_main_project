
<?php
session_start();
if(isset($_SESSION['users_login'])){
include 'connect.php'; 
$uid = $_SESSION['users_login'];

?><!DOCTYPE html>
<html>
<head>
	<title>Police Home page</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

 
    

  

</head>
<body>
<?php echo "Place-".$place; ?>

	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><b>Crimopedia </b></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
      
       
</ul>
      <ul class="nav navbar-nav navbar-right">
       
        <li><a href="p_logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
      </ul>
      <h3><center>Complaint Details</center></h>  
    </div>
  </div>
 </nav>
 
 <div style="padding:50px;margin-top:5%;">
   <table class="table table-bordered">
    <thead class="thead-dark" style="background-color: black; color: white;">
      <tr>
      <th scope="col">No:</th>
      <th scope="col">Name</th>
      <th scope="col">Aadhar Number</th>
      <th scope="col">Date</th>
      <th scope="col">Description</th>
      <!-- <th scope="col">Status</th> -->
      <th scope="col">Crime</th>
      <th scope="col">location</th>
      <th scope="col">Status</th>
  
      <th scope="col">Action</th>
      <th scope="col">Request</th>
      
        
      </tr>
    </thead>

<?php
//$sql11= "select * from police_officer where login_id = '$uid'";
//echo $sql11;
//$qr = mysqli_query($con,$sql11) ;
//$row = mysqli_fetch_assoc($qr);
//$place = $row['o_policestation'];
//echo "Place-".$place;
$sql1="select * from `complaint_registration` JOIN user_registration ON complaint_registration.us_id=user_registration.us_id where location='$place'";
$sql="select * from `complaint_registration` where c_status='pending'";
//echo $sql; 
$result=mysqli_query($con,$sql);
if($result)
      while($row=mysqli_fetch_assoc($result)){
        $i=0;
        $i++;

    ?> 
    <tbody style="background-color: white; color: black;">
      <tr>
      <td><?php echo $i ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['aadhar_number']; ?></td>
<td><?php echo $row['c_date']; ?></td>
<td><?php echo $row['c_description']; ?></td>
<!-- <td><?php echo $row['c_status']; ?></td> -->

<td><?php echo $row['type_crime']; ?></td>
<td><?php echo $row['location']; ?></td>
<td><?php echo $row['c_status']; ?></td>
<td><?php if($row['c_status']==0){?>
  <?php
  }
 ?>
 <a href="com_status.php?s_id=<?php echo $row['cid']; ?>&&status=0" >
<input type="submit" value="proceed"></a></td>

<td>
<button class="btn btn-dark"><a href="policerequest.php?" class="text-light">Request</a></button>

 <td>
          
      </tr>
    </tbody>
    
    <?php
    } 
    ?>
  
</table>
 </div>
 <?php }
 else{
   echo "unauthorized accesss";
 }?>

 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>