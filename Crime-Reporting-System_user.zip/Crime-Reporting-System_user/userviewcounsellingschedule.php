<?php
include 'connect.php';
session_start();
if($_SESSION['users_login']==""){
  header("location:userlogin.php");
}
$usr = $_SESSION['users_login'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>User_Home</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
  <style>
    body {
    background-size: cover;
    background-color:white;
    background-position: center; 
}

body,
html {
    width: 100%;
    height: 100%;
    font-family: "Lato";
    color: white;
}

h1 {
  font-weight: 700;
  font-size: 5em;
}


.content{
  padding-top: 25%;
  text-align: center;
    text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
                 0px 8px 13px rgba(0,0,0,0.1),
                 0px 18px 23px rgba(0,0,0,0.1);
}

hr {
    width: 250px;
    border-top: 1px solid #f8f8f8;
    border-bottom: 1px solid rgba(0,0,0,0.2);
}
</style>	
     
</head>
<body>
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="userhome.php"><b>Home</b></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        <!--<li class="active" ><a href="complainer_page.php">Add Complaint</a></li>
        <li class="active"><a href="complaint_status.php">View complaint status</a></li>
        <li class="active"><a href="list_policestation.php">Police Station</a></li>-->
      </ul>
      <ul class="nav navbar-nav navbar-right">
       
      
       <li><a href="logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
     </ul>
    </div>
  </div>
 </nav>
<div style="padding:50px;">
</div>
<div style="padding:50px;">
   <table class="table table-bordered">
    <thead class="thead-dark" style="background-color: black; color: white;">
    <thead class="thead-dark" style="background-color: black; color: white;">
      <tr>
     
      <th scope="col"> Counsellor Name</th>
      <th scope="col">Date</th>
      <th scope="col">Time</th>
      <th scope="col">Office</th>
      <th scope="col">Location</th>
      
      
        
      </tr>
    </thead>
    <?php
    

   $sql="select complaint_registration.type_crime,tbl_schedule.s_date,tbl_schedule.sid,tbl_schedule.s_time,tbl_schedule.status,counselling.co_name,counselling.co_office,counselling.co_city ,counselling.co_district,counselling_request.coid,user_registration.name,counselling_request.req_id from counselling_request 
   join complaint_registration on complaint_registration.cid=counselling_request.cid join police_officer on police_officer.login_id=counselling_request.login_id JOIN user_registration ON user_registration.login_id=complaint_registration.login_id and counselling_request.coid JOIN tbl_schedule on tbl_schedule.req_id=counselling_request.req_id
    JOIN counselling ON counselling.coid=counselling_request.coid where complaint_registration.login_id=user_registration.login_id and user_registration.login_id='$usr'; ";
   $result=mysqli_query($con,$sql);
if($result)
      while($row=mysqli_fetch_assoc($result)){
    ?> 

    <tbody style="background-color: white; color: black;">
      <tr>
     
<td><?php echo $row['co_name']; ?></td>
<td><?php echo $row['s_date']; ?></td>
<td><?php echo $row['s_time']; ?></td>
<td><?php echo $row['co_office']; ?></td>
<td><?php echo $row['co_city']; ?></td>
<!--<td><form method="post "><input type="hidden" name="cid" value="<?php echo $row['cid'];?>">
<button type="submit" name="viewdetails">View Details</button>
      </form>-->
      </td>
     </tr>
     <?php
     }
     ?>
    </tbody>
    <!--<?php
    if(isset($_POST['viewdetails']))
    {
      $cid=$_POST['cid'];
      $_SESSION['cid']=$cid;
      header("location:complaint_status_pdf.php");
    }
    ?>-->
</table>



 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>