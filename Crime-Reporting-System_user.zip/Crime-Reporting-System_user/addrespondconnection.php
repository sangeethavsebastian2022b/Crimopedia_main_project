<?php
session_start();
$uid = $_SESSION['users_login'];
$logid=$_SESSION['logid'];
// $cid = $_POST['id'];
include 'connect.php'; 
if (isset($_POST['submit'])) {
    //$cid = $_POST['cid'];
    

    $response = $_POST['response'];
    //$counsellor = $_POST['counsellor']; 
$sql= "INSERT INTO `tbl_policerespond`( `cid`,`response`) 
        VALUES ('$logid','$response')";
        echo $sql;
$dd = mysqli_query($con,$sql);
echo "<script>alert('insertion successfully')</script>";
header("location:viewcomplaints.php");
}

?>