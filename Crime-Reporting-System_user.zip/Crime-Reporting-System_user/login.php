<?php
include 'connect.php';
session_start();
if(isset($_SESSION['user_login']))
{
 header("location:userhome.php");

}


if (isset($_POST['s']))
{
    $email= mysqli_real_escape_string($con,$_POST['email']);
    $password= mysqli_real_escape_string($con,$_POST['password']);

    $sql=mysqli_query($con,"SELECT * from `users_login` where `email`='$email' and `password`='$password'");
   while($row=mysqli_fetch_assoc($sql))
   
    {
       if($row['role']=='user' && $row['status']=='1')
      {
	      $_SESSION['users_login']=$row['login_id'];
          
        header('location:userhome.php');

    }                            
        elseif($row['role']=='admin' && $row['status']=='1')
        {
            $_SESSION['users_login']=$row['login_id'];
            
            header('location:dashboard.php');
        } 
        elseif($row['role']=='police' && $row['status']=='1')
        {
            $_SESSION['users_login']=$row['login_id'];
            
            header('location:policedashboard.php');
        } 
        elseif($row['role']=='lawyer' && $row['status']=='1')
        {
            $_SESSION['users_login']=$row['login_id'];
           
            header('location:lawyerdashboard.php');
        } 
        elseif($row['role']=='counsellor' && $row['status']=='1')
        {
            $_SESSION['users_login']=$row['login_id'];
           
            header('location:counsellordashboard.php');
        } 
         
    else{
        
        header('location:userlogin.php');
    }
}
}
?>