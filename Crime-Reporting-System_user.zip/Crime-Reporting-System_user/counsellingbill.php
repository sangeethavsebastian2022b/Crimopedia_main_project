<?php
 $apiKey="rzp_test_ONOZjRbrcY2YZv";
 include 'connect.php';
 $tid=$_GET['tid'];
 $pid=$_GET['pid'];
  session_start();
  if($_SESSION['users_login']==""){
    header("location:userlogin.php");
  }
  $usr = $_SESSION['users_login'];
 // $sec_id=$_GET['id'];
  
 $id=$_SESSION['users_login'];
 $query="SELECT * FROM users_login where login_id ='$id'";
 $res = mysqli_query($con,$query);
 $r=mysqli_fetch_array($res);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crimopedia</title>
    <style>
        body{
            background-color: #F6F6F6; 
            margin: 0;
            padding: 0;
        }
        h1,h2,h3,h4,h5,h6{
            margin: 0;
            padding: 0;
        }
        p{
            margin: 0;
            padding: 0;
        }
        .container{
            width: 80%;
            margin-right: auto;
            margin-left: auto;
            margin-top: 1%;
        }
        .brand-section{
           background-color: rgb(11, 11, 94);
           padding: 10px 40px;
        }
        .logo{
            width: 50%;
        }

        .row{
            display: flex;
            flex-wrap: wrap;
        }
        .col-6{
            width: 50%;
            flex: 0 0 auto;
                    }
        .col-6-1{
            flex: 0 0 auto;
            margin-top: -10%;
            margin-left: 35%;
        }
        .text-white{
            color: #fff;
        }
        .company-details{
            float: right;
            text-align: right;
        }
        .body-section{
            padding: 16px;
            border: 1px solid gray;
        }
        .heading{
            font-size: 20px;
            margin-bottom: 08px;
        }
        .sub-heading{
            color: #262626;
            margin-bottom: 05px;
        }
        table{
            background-color: #fff;
            width: 100%;
            border-collapse: collapse;
        }
        table thead tr{
            border: 1px solid #111;
            background-color: #f2f2f2;
        }
        table td {
            vertical-align: middle !important;
            text-align: center;
        }
        table th, table td {
            padding-top: 08px;
            padding-bottom: 08px;
        }
        .table-bordered{
            box-shadow: 0px 0px 5px 0.5px gray;
        }
        .table-bordered td, .table-bordered th {
            border: 1px solid #dee2e6;
        }
        .text-right{
            text-align: end;
        }
        .w-20{
            width: 20%;
        }
        .float-right{
            float: right;
        }
        .prnt{
	        color: white;
	        text-align: center;
	        font-size: 18px;
	        padding: 5px;
	        width: 14%;
	        height: 6%;
	        transition: all 0.5s;
	        cursor: pointer;
	        margin-left: 85%;
	        margin-top:-800% ;

        }
        .prnt1{
            display: inline-block;
	        border-radius: 20px;
	        border: 1px solid #4B5251;
	        color: #4B5251;
	        text-align: center;
	        font-size: 18px;
	        padding: 5px;
	        width: 14%;
	        height: 6%;
	        transition: all 0.5s;
	        cursor: pointer;
	        margin-left: 70%;
	        margin-top:-5% ; 
        }
        .prnt:hover{
            background-color: black;
        }
        .body-section1{
            background-color: rgb(11, 11, 94);
            padding: 16px;
            border: 1px solid gray;
        }
    </style>
    <style>
        .btn {
  background-color: DodgerBlue;
  border: none;
  color: white;
  padding: 12px 30px;
  cursor: pointer;
  font-size: 20px;
}

/* Darker background on mouse-over */
.btn:hover {
  background-color: RoyalBlue;
}
        </style>
</head>
<body>

    <div class="container">
        <div class="brand-section">
            <div class="row">
                <div class="col-6">
                <link href="Images1/applogo.png" rel="icon">
                    <h1 class="text-white">Crimopedia</h1>
                </div>
                <div class="col-6">
                   <!-- <div class="company-details">
                        <p class="text-white">autorsvba@gmail.com</p>
                        <p class="text-white">AUTORS-Vehicle BreakDown Assistance</p>
                        <p class="text-white">+989 345 6789</p>
                    </div>-->
                </div>
            </div>
        </div>

        <div class="body-section">
            <div class="row">
            <?php
$l=$_GET['id'];
$id=$_SESSION['users_login'];
//select * from request_tbl rq,reg_tbl re,mec_tbl m,assign_tbl a,completedtask_tbl cp where rq.req_id=cp.req_id and a.req_id=cp.req_id and re.log_id='$id' AND rq.log_id='$id' AND a.log_id='$id' and rq.req_id='$req' AND a.req_id='$req'and m.mec_id=a.mechanic
$query5="select * from tbl_payment_adv where  request_id='$l'";
  $res4 = mysqli_query($con,$query5);
  $r4=mysqli_fetch_array($res4);
?>
                <div class="col-6">
                <div id="print_section">
                    <h2 class="heading" onclick="printbill('print_section')" value="Download" class="fa fa-download" ><button class="btn"><i class="fa fa-download"></i> Invoice</button></h2>
    </div>
                    <p class="sub-heading" id="dash_date"> Date: </p>
                        <script>
                        var today = new Date();
                        var date = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();
                        document.getElementById("dash_date").innerHTML = "Order Date : "+date;
                        </script>
                    
                    <p>Email Address:<?php echo $r["email"]."</p>"; ?>
                    </p>
                </div> 
                
            </div>
        </div>

        <div class="body-section">
        <!--<h3 class="heading">Booked Vehicle</h3>-->
            <br>
            <table class="table-bordered">
            <tr>
                   <th style="padding-left:-25px;"  >User Name</th>
                    <th style="padding-left:7px;" >consulting fee</th>
                    
                    <th style="padding-left:20px;">Grand Total</th>
                </tr>


            <tbody>
           <?php
            $sno = 1;
            $total= 0;
            $reqid=$_GET['id'];
            $fecthReserve="SELECT * FROM complaint_registration JOIN user_registration ON user_registration.login_id=complaint_registration.login_id 
            JOIN counselling_request ON complaint_registration.cid=counselling_request.cid JOIN tbl_schedule ON tbl_schedule.req_id= counselling_request.req_id JOIN tbl_remark on tbl_remark.sid=tbl_schedule.sid JOIN police_officer ON police_officer.login_id=counselling_request.login_id JOIN counselling ON counselling.coid=counselling_request.coid JOIN tbl_amount ON tbl_amount.coid=counselling.coid 
            JOIN users_login ON users_login.login_id=user_registration.login_id and user_registration.login_id='$usr'";
    $fecthReserveResult=mysqli_query($con,$fecthReserve);
    while($fecthReserveRow=mysqli_fetch_array($fecthReserveResult)){
        $total+=$fecthReserveRow['amount'];
       echo "<tr>
        <td style=padding-left:25px;>".$fecthReserveRow['name']."</td>
        <td style=padding-left:25px;>".$fecthReserveRow['amount']."</td>
        </tr><br>";
    }
        #$tax=50;
        #echo"<tr>
        #<td></td><td></td>
        #<td><b> Sub Total </td>
        #<td> $total</td></b></tr>";
        #echo"<tr>
        #<td></td><td></td>
        #<td><b> Tax </td>
        #<td> $tax</td></b></tr>";
        $grand_total=$total;
        echo"<tr>
        <td></td><td></td>
       
        <td> $grand_total</td></b></tr>";
            ?>
                    
            </table>
            <br>
            <h4>Transaction ID: <?php echo $tid .':'.$pid?></h4>
           <!-- <h3 class="heading" style="margin-left:2%;">Payment Status: <?php echo $r4["status"]."</h3>"; ?>-->
            <h3 class="heading"style="margin-left:2%;">Payment Mode: Online Payment</h3>
           <!-- <h3 class="heading"style="margin-left:2%;">Payment Date:<?php echo $r4["date_added"]."</h3>"; ?>-->
            </div>
            <!--<div>
            <a href="#" class="prnt1">Submit</a></div>-->
           <!--<div id="print_section">
             <input type="button" class="prnt"onclick="printbill('print_section')" value="Download">
        </div>-->

        <div class="body-section1">

        <a href='counsellingcertificate_pdf.php'><i style="margin-left:50%;" class="text-white"> Thank You for Visiting...</i></a>
            </p>
        </div>      
    </div>      
<script>
    function printbill(section_id){
    window.print();
    }
    
</script>

</body>
</html>