<?php
 $apiKey="rzp_test_ONOZjRbrcY2YZv";
 include 'connect.php';
 $tid=$_GET['tid'];
  session_start();
  if($_SESSION['users_login']==""){
    header("location:userlogin.php");
  }
  $usr = $_SESSION['users_login'];
 // $sec_id=$_GET['id'];
  
  
 
$id=$_SESSION['users_login'];
$query="SELECT * FROM users_login where login_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);

if($r[4]==1)
{

  $query1="SELECT * FROM user_registration where login_id ='$id'";
  $res1 = mysqli_query($con,$query1);
  $r1=mysqli_fetch_array($res1);


?>

          <?php
            
   
    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');  
    $u=$_SESSION['users_login'];
     $l=$_GET['id'];
     $sql = mysqli_query($con, "select add_lawyer.*,tbl_amount_adv.*,tbl_consult.* from add_lawyer,tbl_amount_adv,tbl_consult where add_lawyer.aid=tbl_amount_adv.aid AND
     add_lawyer.sec_id=tbl_consult.section and tbl_consult.login_id='$u' and tbl_consult.request_id='$l'");
     $r6 = mysqli_fetch_array($sql);
    
     $amt=$r6['amount'];
       
       
    
    echo $id;
    echo $l;
    $sql1="INSERT INTO tbl_payment_adv(request_id,amount,status) VALUES ('$l','$amt','paid')";
    mysqli_query($con,$sql1);
    $pid=mysqli_insert_id($con);
    // if($i=='Unpaid')
    // {
    // $sql = mysqli_query($con, "UPDATE `booking_tbl` SET `pstatus`='Paid' WHERE bk_id='$l' and log_id='$id'");
    if (headers_sent()) {
      ?>
    <script>
      alert("Paid Successfully");
      </script>
    <?php
      die('<script type="text/javascript">window.location.href="bill.php?id='.$l.'" </script>');
    } else {
      header("location:bill.php?id=".$l."&&tid=$tid&&pid=$pid");
      die();
    }   
    }
    
    
      

  
?>
          