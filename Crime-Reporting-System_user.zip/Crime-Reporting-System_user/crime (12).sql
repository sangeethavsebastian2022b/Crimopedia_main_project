-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 19, 2022 at 05:40 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crime`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_lawyer`
--

CREATE TABLE `add_lawyer` (
  `aid` int(10) NOT NULL,
  `a_name` varchar(200) NOT NULL,
  `mobile` int(20) NOT NULL,
  `office_address` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `district` varchar(200) NOT NULL,
  `experience` int(20) NOT NULL,
  `sec_id` int(11) NOT NULL,
  `court` varchar(200) NOT NULL,
  `login_id` int(10) NOT NULL,
  `qualification` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_lawyer`
--

INSERT INTO `add_lawyer` (`aid`, `a_name`, `mobile`, `office_address`, `city`, `state`, `district`, `experience`, `sec_id`, `court`, `login_id`, `qualification`) VALUES
(1, 'Raj Nandu', 987666678, 'Legaly', 'Kottayam', 'Kerala', 'Kottayam', 10, 4, 'Munsif Court', 61, 'B.A,L.L.B'),
(2, 'Bhagya Sree', 987656746, 'Bhagya legal support', 'Kochi', 'Kerala', 'Kochi', 3, 1, 'Munsif court', 63, 'B.COM,L.L.B'),
(3, 'Raveendran Raja', 987656778, 'Adv. Raveendran Raja', 'Kanjirappally', 'Kerala', 'Kottayam', 20, 6, 'District Court,Kottayam', 64, 'B.A,L.L.M,L.L.B'),
(4, 'Divya Chandran', 986786778, 'Adv. Divya Chandran', 'Vaikom', 'Kerala', 'Kottayam', 15, 3, 'SUB COURT Kottayam', 75, 'B.A,L.L.M,L.L.B'),
(5, 'Laya Thomas', 967567676, 'Adv Laya Thomas', 'Kaduthuruthy', 'Kerala', 'Kottayam', 10, 5, 'District Court Kottayam', 76, 'B.A,L.L.M,L.L.B'),
(6, 'Thinkal Tom', 996149133, 'Adv. Laya Tom, domestic violence lawyer', 'Kottaym', 'Kerala', 'Kottayam', 7, 1, 'District Court Kottayam', 77, 'B.A,L.L.B'),
(7, 'Roy Varghese', 987867656, 'Adv. Roy Varghese', 'Kottayam', 'Kerala', 'Kottayam', 10, 1, 'SUB COURT THODUPUZHA', 78, 'B.A,L.L.B');

-- --------------------------------------------------------

--
-- Table structure for table `complaint_registration`
--

CREATE TABLE `complaint_registration` (
  `cid` int(11) NOT NULL,
  `c_date` date NOT NULL,
  `c_description` varchar(100) NOT NULL,
  `c_status` varchar(11) NOT NULL,
  `type_crime` int(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `login_id` int(11) NOT NULL,
  `reason` varchar(50) NOT NULL,
  `solution` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `incident_date` date NOT NULL,
  `incident_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `complaint_registration`
--

INSERT INTO `complaint_registration` (`cid`, `c_date`, `c_description`, `c_status`, `type_crime`, `location`, `login_id`, `reason`, `solution`, `status`, `incident_date`, `incident_time`) VALUES
(77, '2022-07-06', 'Domestic Violence', 'Approved', 8, 'Kottayam West', 56, 'nil', 'Take action immediately', 1, '2022-06-29', '21:52:00'),
(79, '2022-07-07', 'Domestic violence at home ', 'pending', 8, '1', 68, 'Dowry', 'Take Action Immediately', 0, '2022-07-05', '10:53:00'),
(80, '2022-07-08', 'Golden chain', 'pending', 2, 'Kottayam ', 68, 'Nil', 'Take Immediate Action', 0, '2022-06-28', '10:49:00'),
(81, '2022-07-08', 'Domestic violence ', 'pending', 8, 'Kottayam ', 81, 'Dowry', 'Take action', 0, '2022-07-08', '08:25:00'),
(82, '2022-07-08', 'Threatening', 'Approved', 8, 'Kottayam ', 82, 'Dowry', 'Solve Issue', 0, '2022-07-05', '11:28:00');

-- --------------------------------------------------------

--
-- Table structure for table `counselling`
--

CREATE TABLE `counselling` (
  `coid` int(10) NOT NULL,
  `co_name` varchar(100) NOT NULL,
  `co_mobile` int(20) NOT NULL,
  `co_office` varchar(100) NOT NULL,
  `co_city` varchar(100) NOT NULL,
  `co_state` varchar(100) NOT NULL,
  `co_district` varchar(100) NOT NULL,
  `counselling_id` int(11) NOT NULL,
  `co_experience` varchar(100) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counselling`
--

INSERT INTO `counselling` (`coid`, `co_name`, `co_mobile`, `co_office`, `co_city`, `co_state`, `co_district`, `counselling_id`, `co_experience`, `login_id`) VALUES
(9, 'Sagar Raj', 689757882, 'Rexal counselling Center', 'Kottayam', 'Kerala', 'Kottayam', 1, '10', 42),
(10, 'Varna Raghav', 986756564, 'Varna counselling center', 'Pala', 'Kerala', 'Kottayam', 3, '9', 51),
(11, 'Vimal ', 987565665, 'Pulpally', 'Sulthan Bathery', 'Kerala', 'Wayanad', 3, '2', 49),
(14, 'Amala Chandran', 985678487, 'Happy life counselling center', 'Kanjirappally', 'Kerala', 'Kottayam', 1, '4', 67),
(15, 'Gayathri Raman', 986754676, 'New life  Counselling Center', 'Kottayam', 'Kerala', 'Kottayam', 4, '13', 79),
(16, 'Sariga Sagar', 987676545, 'Happy Counselling Center', 'Pala', 'Kerala', 'Kottayam', 4, '13', 80);

-- --------------------------------------------------------

--
-- Table structure for table `counselling_request`
--

CREATE TABLE `counselling_request` (
  `req_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `section` varchar(25) NOT NULL,
  `coid` int(11) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counselling_request`
--

INSERT INTO `counselling_request` (`req_id`, `login_id`, `cid`, `section`, `coid`, `status`) VALUES
(67, 17, 77, '1', 9, 1),
(68, 17, 82, '1', 9, 0),
(69, 17, 82, '4', 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `counselling_section`
--

CREATE TABLE `counselling_section` (
  `counselling_id` int(10) NOT NULL,
  `counselling_section` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `counselling_section`
--

INSERT INTO `counselling_section` (`counselling_id`, `counselling_section`) VALUES
(1, 'Marriage and family'),
(2, 'Guidance counseling'),
(3, 'Rehabilitation counseling.'),
(4, 'Mental health counseling'),
(5, 'Substance Abuse counseling');

-- --------------------------------------------------------

--
-- Table structure for table `crime_section`
--

CREATE TABLE `crime_section` (
  `crime_id` int(11) NOT NULL,
  `crime` varchar(100) NOT NULL,
  `crime_section` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `crime_section`
--

INSERT INTO `crime_section` (`crime_id`, `crime`, `crime_section`) VALUES
(1, 'Murder', 'Section 302'),
(2, 'Theft', 'Section378'),
(3, 'Robbery', 'IPC Section 390'),
(4, 'Pickpocket', 'IPC Section 511(b)'),
(5, 'Molestation', 'IPC Section 354'),
(6, 'Kidnapping', 'IPC Section 360'),
(7, 'Missing Person', 'IPC Section 154'),
(8, 'Domestic Violence against women', 'IPC Section 498A'),
(9, 'Women traffiking', 'IPC Section 370'),
(10, 'Acid throwing', 'IPC Section 326 A'),
(11, 'Sexual Harassment', 'IPC Section 354 '),
(12, 'Chain Snatching', 'IPC Section 379A and 379B'),
(13, 'Stalking', 'IPC Section 364D'),
(14, 'Corporal punishment and physical violence in the home', 'IPC Section 17(1)'),
(15, 'Corporal punishment and physical violence in the school', 'IPC Section 17(2)');

-- --------------------------------------------------------

--
-- Table structure for table `lawyer_section`
--

CREATE TABLE `lawyer_section` (
  `sec_id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lawyer_section`
--

INSERT INTO `lawyer_section` (`sec_id`, `category`) VALUES
(1, 'Domestic violence'),
(2, 'Court Marriage'),
(3, 'Divorce'),
(4, 'Alimony'),
(5, 'Judicial'),
(6, 'Civil Lawyer'),
(7, 'Property Lawyer');

-- --------------------------------------------------------

--
-- Table structure for table `policestation`
--

CREATE TABLE `policestation` (
  `p_id` int(11) NOT NULL,
  `o_policestation` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `policestation`
--

INSERT INTO `policestation` (`p_id`, `o_policestation`) VALUES
(1, 'Kottayam '),
(2, 'Changanacherry'),
(3, 'Kottayam West'),
(4, 'Kuravilangadu'),
(5, 'Karukachal'),
(6, 'Pala Town'),
(7, 'Vaikom'),
(8, 'Mundakayam'),
(10, 'Pampady'),
(11, 'Manimala'),
(12, 'Erattupetta'),
(13, 'Kanjirappally'),
(14, 'Ettumanur'),
(15, 'Chingavanam'),
(16, 'Kaduthuruthy'),
(17, 'Maragattupally'),
(18, 'Erumely'),
(19, 'Manarcaudu'),
(20, 'Vakathanam'),
(21, 'Kidangoor'),
(23, 'Kottayam East');

-- --------------------------------------------------------

--
-- Table structure for table `police_officer`
--

CREATE TABLE `police_officer` (
  `login_id` int(20) NOT NULL,
  `officer_name` varchar(100) NOT NULL,
  `o_policestation` varchar(100) NOT NULL,
  `officer_rank` varchar(100) NOT NULL,
  `officer_location` varchar(100) NOT NULL,
  `officer_id` int(11) NOT NULL,
  `zone` varchar(100) NOT NULL,
  `range` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `police_officer`
--

INSERT INTO `police_officer` (`login_id`, `officer_name`, `o_policestation`, `officer_rank`, `officer_location`, `officer_id`, `zone`, `range`) VALUES
(4, 'Raj', 'Ettumanur', 'Circle', 'Ettumanur', 4, 'south', 'Ernakulam'),
(5, 'Kumar', 'Beypore census Town', 'Circle Inspector of police', 'Beypore census Town', 5, 'south', 'Ernakulam'),
(17, 'Vijay Chandran', 'Kottayam', 'Circle Inspector of police', 'Kottayam West', 6, 'South', 'Ernakulam'),
(70, 'Chandra Das', 'Kuravilangadu', 'Circle Inspector of Police', 'Kuravilangadu', 10, 'South', 'Ernakulam'),
(71, 'Rama Chandran', 'Karukachal', 'Circle Inspector of Police', 'Karukachal', 11, '', 'Ernakulam'),
(72, 'Srijith A.S', 'Pala Town', 'Circle Inspector of Police', 'Pala Town', 12, 'South', 'Ernakulam'),
(73, 'David Thomas', 'Vaikom', 'Circle Inspector of Police', 'Vaikom', 13, 'South', 'Ernakulam'),
(74, 'Raghuram', 'Mundakayam', 'Circle Inspector of Police', 'Mundakayam', 14, 'South', 'Ernakulam');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_amount`
--

CREATE TABLE `tbl_amount` (
  `amount_id` int(11) NOT NULL,
  `coid` int(11) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_amount`
--

INSERT INTO `tbl_amount` (`amount_id`, `coid`, `amount`) VALUES
(1, 9, 1000),
(2, 10, 1000),
(3, 11, 1000),
(4, 12, 1000),
(5, 12, 1000),
(6, 13, 1000),
(7, 14, 1000),
(8, 15, 1000),
(9, 16, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_amount_adv`
--

CREATE TABLE `tbl_amount_adv` (
  `amount_id` int(11) NOT NULL,
  `aid` int(11) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_amount_adv`
--

INSERT INTO `tbl_amount_adv` (`amount_id`, `aid`, `amount`) VALUES
(1, 1, 1000),
(2, 2, 1000),
(3, 3, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_assign`
--

CREATE TABLE `tbl_assign` (
  `assign_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `l_section` int(11) NOT NULL,
  `lawyer_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_assign`
--

INSERT INTO `tbl_assign` (`assign_id`, `request_id`, `l_section`, `lawyer_name`) VALUES
(14, 17, 2, '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_consult`
--

CREATE TABLE `tbl_consult` (
  `request_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `mode` varchar(10) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `section` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_consult`
--

INSERT INTO `tbl_consult` (`request_id`, `login_id`, `date`, `time`, `mode`, `comment`, `section`) VALUES
(17, 56, '2022-07-23', '10:27:00', 'Offline', 'dzfg', '2'),
(27, 69, '2022-07-14', '13:31:00', 'Online', 'Test', '1'),
(29, 56, '2022-07-10', '11:46:00', 'Offline', 'Asdf', '3'),
(30, 82, '2022-07-20', '15:29:00', 'Offline', 'Adghghj', '1'),
(31, 82, '2022-07-19', '11:30:00', '', 'legal matter', '1'),
(35, 82, '2022-07-20', '17:24:00', 'Offline', 'Fhhjjkj', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment_adv`
--

CREATE TABLE `tbl_payment_adv` (
  `p_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_payment_adv`
--

INSERT INTO `tbl_payment_adv` (`p_id`, `request_id`, `amount`, `date`, `status`) VALUES
(21, 27, 1000, '2022-07-07 05:06:00', 'paid'),
(25, 35, 1000, '2022-07-19 06:59:08', 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment_counselling`
--

CREATE TABLE `tbl_payment_counselling` (
  `pay_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_policerespond`
--

CREATE TABLE `tbl_policerespond` (
  `res_id` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `response` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_remark`
--

CREATE TABLE `tbl_remark` (
  `rid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `coid` int(11) NOT NULL,
  `remark` varchar(200) NOT NULL,
  `completiondate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_remark`
--

INSERT INTO `tbl_remark` (`rid`, `sid`, `coid`, `remark`, `completiondate`) VALUES
(13, 74, 15, 'Completed Successfully', '2022-07-13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_schedule`
--

CREATE TABLE `tbl_schedule` (
  `sid` int(11) NOT NULL,
  `s_date` date NOT NULL,
  `s_time` time NOT NULL,
  `s_location` varchar(50) NOT NULL,
  `req_id` int(11) NOT NULL,
  `coid` int(11) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_schedule`
--

INSERT INTO `tbl_schedule` (`sid`, `s_date`, `s_time`, `s_location`, `req_id`, `coid`, `status`) VALUES
(72, '2022-07-08', '10:30:00', '', 67, 9, 0),
(74, '2022-07-11', '10:46:00', '', 69, 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_login`
--

CREATE TABLE `users_login` (
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `login_id` int(11) NOT NULL,
  `role` varchar(10) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_login`
--

INSERT INTO `users_login` (`email`, `password`, `login_id`, `role`, `status`) VALUES
('sangeetha@gmail.com', '123456', 1, 'admin', 1),
('silja@gmail.com', 'Silja@12', 7, 'user', 1),
('vv@gmail.com', 'Vv@12345', 17, 'police', 1),
('sagar@gmail.com', 'Sagar@12', 42, 'counsellor', 1),
('pauline@gmail.com', 'P@s12345', 44, 'user', 1),
('Srdshghg@h.jk', 'Srdshghg#%#12', 47, 'user', 1),
('Vimal@mail.com', 'vimal@12', 49, 'counsellor', 1),
('varna@gmail.com', 'Varna@12', 51, 'counsellor', 1),
('sangeethasebastian@gmail.com', 'Sangeetha@98', 55, 'user', 1),
('arathy@gmail.com', 'Arathy@12', 56, 'user', 1),
('aparna@gmail.com', 'Aparna@12', 57, 'user', 1),
('rajitha@gmail.com', 'Rajitha@12', 58, 'user', 1),
('av@gamil.com', 'Av@12345', 61, 'lawyer', 1),
('bhagyasree@gmail.com', 'Bhagya@12', 63, 'lawyer', 1),
('ravi@gmail.com', 'Ravi@123', 64, 'lawyer', 1),
('Addddddd@gmail.com', 'Addddddd@12', 65, 'lawyer', 1),
('rajeev@gmail.com', 'Rajeev@12', 66, 'counsellor', 1),
('amala@gmail.com', 'Amala@12', 67, 'counsellor', 1),
('radha@gmail.com', 'Radha@12', 68, 'user', 1),
('sameera@gmail.com', 'Sameera@12', 69, 'user', 1),
('das@gmail.com', 'Das@1234', 70, 'police', 1),
('rama@gmail.com', 'Rama@1234', 71, 'police', 1),
('srijith@gmail.com', 'Srijith@12', 72, 'police', 1),
('thomas@gmail.com', 'Thomas@12', 73, 'police', 1),
('raghuram@gmail.com', 'Raghuram@12', 74, 'police', 1),
('divya@gmail.com', 'Divya@12', 75, 'lawyer', 1),
('laya@gmail.com', 'Laya@123', 76, 'lawyer', 1),
('thinkal@gmail.com', 'Thinkal@12', 77, 'lawyer', 1),
('roy@gmail.com', 'Roy@1234', 78, 'lawyer', 1),
('gayathri@gmail.com', 'Gayathri@12', 79, 'counsellor', 1),
('Sariga@gmail.com', 'Sariga@12', 80, 'counsellor', 1),
('parvathy@gmail.com', 'Parvathy@12', 81, 'user', 1),
('chithra@gmail.com', 'Chithra@12', 82, 'user', 1),
('antonyscaria0904@gmail.com', 'Antony@12', 85, 'user', 1),
('Sarang@gmail.com', 'Sarang@12', 86, 'user', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE `user_registration` (
  `us_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address1` varchar(30) NOT NULL,
  `address2` varchar(30) NOT NULL,
  `address3` varchar(30) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `login_id` int(10) NOT NULL,
  `aadhar_number` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`us_id`, `name`, `address1`, `address2`, `address3`, `dist`, `state`, `gender`, `login_id`, `aadhar_number`) VALUES
(15, 'Sangeetha V Sebastian', 'Vengappallil', 'Kattappana', 'Kattappana', 'Idukki', 'Kerala', 'Female', 55, '878887765556'),
(16, 'Arathy Nair', 'Arathy bhavan', 'Ettumanur', 'Kottayam', 'Kottayam', 'Kerala', 'Female', 56, '978787678654'),
(17, 'Aparna Ragav', 'Ragava house', 'Kottayam', 'Kottayam', 'Kottayam', 'Kerala', 'Female', 57, '989778876557'),
(18, 'Rajitha Soman', 'Nirmal house', 'Kottayam', 'Kottayam', 'Kottayam', 'Kerala', 'Female', 58, '119878877766'),
(19, 'Radha Gopalan', 'Kishna Vilas', 'Kottayam', 'Kottayam', 'Kottayam', 'Kerala', 'Female', 68, '986785674777'),
(20, 'Sameera Sajan', 'Pala', 'Pala', 'Kottayam', 'Kottayam', 'Kerala', 'Female', 69, '876856456677'),
(21, 'Parvathy Sumesh', 'Alamoottil', 'Pala', 'Kottayam', 'Kottayam', 'Kerala', 'Female', 81, '767788899999'),
(22, 'Chithra Raj', 'Kottayam', 'Kottayam', 'Kottayam', 'Kottayam', 'Kerala', 'Female', 82, '988987766778'),
(25, 'Antony', 'Kanappilly', 'Koonammavu', 'Ernakulam', 'Ernakulam', 'Kerala', 'Male', 85, '612660634898'),
(26, 'Sarang', 'Sbhhh', 'Sbhhh', 'Sbhhh', 'Thiruvananthapuram', 'Kerala', 'Male', 86, '767890987654');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_lawyer`
--
ALTER TABLE `add_lawyer`
  ADD PRIMARY KEY (`aid`),
  ADD KEY `login_id` (`login_id`),
  ADD KEY `category` (`sec_id`);

--
-- Indexes for table `complaint_registration`
--
ALTER TABLE `complaint_registration`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `type_crime` (`type_crime`);

--
-- Indexes for table `counselling`
--
ALTER TABLE `counselling`
  ADD PRIMARY KEY (`coid`);

--
-- Indexes for table `counselling_request`
--
ALTER TABLE `counselling_request`
  ADD PRIMARY KEY (`req_id`),
  ADD KEY `login_id` (`login_id`),
  ADD KEY `cid` (`cid`),
  ADD KEY `coid` (`coid`);

--
-- Indexes for table `counselling_section`
--
ALTER TABLE `counselling_section`
  ADD PRIMARY KEY (`counselling_id`);

--
-- Indexes for table `crime_section`
--
ALTER TABLE `crime_section`
  ADD PRIMARY KEY (`crime_id`);

--
-- Indexes for table `lawyer_section`
--
ALTER TABLE `lawyer_section`
  ADD PRIMARY KEY (`sec_id`);

--
-- Indexes for table `policestation`
--
ALTER TABLE `policestation`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `police_officer`
--
ALTER TABLE `police_officer`
  ADD PRIMARY KEY (`officer_id`);

--
-- Indexes for table `tbl_amount`
--
ALTER TABLE `tbl_amount`
  ADD PRIMARY KEY (`amount_id`);

--
-- Indexes for table `tbl_amount_adv`
--
ALTER TABLE `tbl_amount_adv`
  ADD PRIMARY KEY (`amount_id`);

--
-- Indexes for table `tbl_assign`
--
ALTER TABLE `tbl_assign`
  ADD PRIMARY KEY (`assign_id`),
  ADD KEY `request_id` (`request_id`);

--
-- Indexes for table `tbl_consult`
--
ALTER TABLE `tbl_consult`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `login_id` (`login_id`);

--
-- Indexes for table `tbl_payment_adv`
--
ALTER TABLE `tbl_payment_adv`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `request_id` (`request_id`);

--
-- Indexes for table `tbl_payment_counselling`
--
ALTER TABLE `tbl_payment_counselling`
  ADD PRIMARY KEY (`pay_id`),
  ADD KEY `login_id` (`login_id`);

--
-- Indexes for table `tbl_policerespond`
--
ALTER TABLE `tbl_policerespond`
  ADD PRIMARY KEY (`res_id`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `tbl_remark`
--
ALTER TABLE `tbl_remark`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `sid` (`sid`),
  ADD KEY `coid` (`coid`);

--
-- Indexes for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `tbl_schedule_ibfk_1` (`req_id`),
  ADD KEY `login_id` (`coid`);

--
-- Indexes for table `users_login`
--
ALTER TABLE `users_login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `user_registration`
--
ALTER TABLE `user_registration`
  ADD PRIMARY KEY (`us_id`),
  ADD KEY `login_id` (`login_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_lawyer`
--
ALTER TABLE `add_lawyer`
  MODIFY `aid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `complaint_registration`
--
ALTER TABLE `complaint_registration`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `counselling`
--
ALTER TABLE `counselling`
  MODIFY `coid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `counselling_request`
--
ALTER TABLE `counselling_request`
  MODIFY `req_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `counselling_section`
--
ALTER TABLE `counselling_section`
  MODIFY `counselling_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `crime_section`
--
ALTER TABLE `crime_section`
  MODIFY `crime_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `lawyer_section`
--
ALTER TABLE `lawyer_section`
  MODIFY `sec_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `policestation`
--
ALTER TABLE `policestation`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `police_officer`
--
ALTER TABLE `police_officer`
  MODIFY `officer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_amount`
--
ALTER TABLE `tbl_amount`
  MODIFY `amount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_amount_adv`
--
ALTER TABLE `tbl_amount_adv`
  MODIFY `amount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_assign`
--
ALTER TABLE `tbl_assign`
  MODIFY `assign_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_consult`
--
ALTER TABLE `tbl_consult`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_payment_adv`
--
ALTER TABLE `tbl_payment_adv`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_payment_counselling`
--
ALTER TABLE `tbl_payment_counselling`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_policerespond`
--
ALTER TABLE `tbl_policerespond`
  MODIFY `res_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_remark`
--
ALTER TABLE `tbl_remark`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `users_login`
--
ALTER TABLE `users_login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `user_registration`
--
ALTER TABLE `user_registration`
  MODIFY `us_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `add_lawyer`
--
ALTER TABLE `add_lawyer`
  ADD CONSTRAINT `add_lawyer_ibfk_1` FOREIGN KEY (`login_id`) REFERENCES `users_login` (`login_id`),
  ADD CONSTRAINT `add_lawyer_ibfk_2` FOREIGN KEY (`sec_id`) REFERENCES `lawyer_section` (`sec_id`);

--
-- Constraints for table `complaint_registration`
--
ALTER TABLE `complaint_registration`
  ADD CONSTRAINT `complaint_registration_ibfk_1` FOREIGN KEY (`type_crime`) REFERENCES `crime_section` (`crime_id`);

--
-- Constraints for table `counselling_request`
--
ALTER TABLE `counselling_request`
  ADD CONSTRAINT `counselling_request_ibfk_1` FOREIGN KEY (`login_id`) REFERENCES `users_login` (`login_id`),
  ADD CONSTRAINT `counselling_request_ibfk_2` FOREIGN KEY (`cid`) REFERENCES `complaint_registration` (`cid`),
  ADD CONSTRAINT `counselling_request_ibfk_3` FOREIGN KEY (`coid`) REFERENCES `counselling` (`coid`);

--
-- Constraints for table `tbl_assign`
--
ALTER TABLE `tbl_assign`
  ADD CONSTRAINT `tbl_assign_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `tbl_consult` (`request_id`);

--
-- Constraints for table `tbl_consult`
--
ALTER TABLE `tbl_consult`
  ADD CONSTRAINT `tbl_consult_ibfk_1` FOREIGN KEY (`login_id`) REFERENCES `users_login` (`login_id`);

--
-- Constraints for table `tbl_payment_adv`
--
ALTER TABLE `tbl_payment_adv`
  ADD CONSTRAINT `tbl_payment_adv_ibfk_2` FOREIGN KEY (`request_id`) REFERENCES `tbl_consult` (`request_id`);

--
-- Constraints for table `tbl_payment_counselling`
--
ALTER TABLE `tbl_payment_counselling`
  ADD CONSTRAINT `tbl_payment_counselling_ibfk_1` FOREIGN KEY (`login_id`) REFERENCES `users_login` (`login_id`);

--
-- Constraints for table `tbl_policerespond`
--
ALTER TABLE `tbl_policerespond`
  ADD CONSTRAINT `tbl_policerespond_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `complaint_registration` (`cid`);

--
-- Constraints for table `tbl_remark`
--
ALTER TABLE `tbl_remark`
  ADD CONSTRAINT `tbl_remark_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `tbl_schedule` (`sid`),
  ADD CONSTRAINT `tbl_remark_ibfk_2` FOREIGN KEY (`coid`) REFERENCES `counselling` (`coid`);

--
-- Constraints for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  ADD CONSTRAINT `tbl_schedule_ibfk_1` FOREIGN KEY (`req_id`) REFERENCES `counselling_request` (`req_id`),
  ADD CONSTRAINT `tbl_schedule_ibfk_2` FOREIGN KEY (`coid`) REFERENCES `counselling` (`coid`);

--
-- Constraints for table `user_registration`
--
ALTER TABLE `user_registration`
  ADD CONSTRAINT `user_registration_ibfk_1` FOREIGN KEY (`login_id`) REFERENCES `users_login` (`login_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
