<?php 
  include 'connect.php';
  session_start();
  if($_SESSION['users_login']==""){
    header("location:userlogin.php");
  }
  $usr = $_SESSION['users_login'];
  //$sec_id=$_GET['id'];
  ?>
  

<!DOCTYPE html>
<html>
  <?php

 include 'connect.php';
 if(isset($_POST['submit']))
 {
  $section=$_POST['section'];
   $date=$_POST['date'];
   $time=$_POST['time'];
   $mode=$_POST['mode'];
   $comment=$_POST['comment'];
   
   $sql="INSERT INTO tbl_consult(`login_id`, `section`, `date`, `time`, `mode`,`comment`) VALUES ('$usr','$section','$date','$time','$mode','$comment')";
   $u=mysqli_query($con,$sql);
    if($u) {
    $l=mysqli_insert_id($con);
  
      header("location:paymentgateway.php?id=".$l."");
      
    }

 }
 
 
 
?> 
<head>
<script>  
    function validate() {  
        var name = document.reg_form.fname;  
          
        if (fname.value.length <= 0) {  
            alert("Name is required");  
            fname.focus();  
            return false;  
        }
        </script>
	<title>Complainer Home Page</title>

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
  <link href="complainer_page.css" rel="stylesheet" type="text/css" media="all" />

<body style="background-size: cover;
    background-image: url(home_bg1.jpeg);
    background-position: center;">
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        
        <li class="active"><a href="Userhome.php">Home</a></li>
      </ul>
     
      <ul class="nav navbar-nav navbar-right">
       
      
        <li><a href="logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
      </ul>
    </div>
  </div>
 </nav>
    
    
<div class="video" style="margin-top: 5%"> 
	<div class="center-container">
		 <div class="bg-agile">
			<br><br>
			<div class="login-form"><p></p><br>
                                    <p><h2> Consultation Details</h2></p><br>	
                                    <form method="post" enctype="multipart/form-data">
                                    <div class="top-w3-agile" style="color:#dfdfdf"><p>Consultation</p>
                                    <select  name="section"  id="consult" required class="form-control">
                        <option selected disabled value="">Select consultation</option>
                        <?php
                        $sel_query =  mysqli_query($con, "select *from lawyer_section");
                        while ($r5 =  mysqli_fetch_array($sel_query)) {
                        ?>
                        <option value="<?php echo $r5['sec_id']; ?>"><?php echo $r5['category']; ?> </option>
                        <?php

                        }
                        ?>
                         </select>
				</div>
                   </br></br>                  <p style="color:#dfdfdf">Date</p>
                                    
<input type="Date"  name="date" id="date"  required="" min="<?= date('Y-m-d');?>"  >
</br> </br> 
<p style="color:#dfdfdf">Time</p>
 <input type="time"  name="time" id="time" required="" >
 </br> 
 </br> <p style="color:#dfdfdf">Consulting mode</p>
 <input type="radio" id="html" name="mode" value="Online">
  <label for="html" style="color:#dfdfdf">Online</label><br>
  <input type="radio" id="offline" name="mode" value="Offline">
   <label for="css" style="color:#dfdfdf">Offline</label><br>
                                                                       
   </br> 

                <p style="color:#dfdfdf">Briefly tell as about your legal matter</p>
                <textarea name="comment" id="legal" required onchange="Validname();"></textarea> <span id="msg3" style="color:red;"></span>
<script>		
function Validname() 
{
    var val = document.getElementById('addr1').value;

    if (!val.match(/^[A-Z][a-z" "]{2,}/)) 
    {
        document.getElementById('msg3').innerHTML="Start with a Capital letter & Only alphabets are allowed";
		            document.getElementById('addr1').value = "";
        return false;
    }
document.getElementById('msg3').innerHTML=" ";
    return true;
}
</script>

</div>





<center><button class="btn btn-primary"  type="submit" value="Submit" id="submit" name="submit" style="color:#dfdfdf" size="100" >Submit</button></center>


</form>
</div>
</div>
</div></div>

			

		
	
<div style="position: relative;
   left: 0;
   bottom: 0;
   width: 100%;
   height: 30px;
   background-color: blue;
   color: white;
   text-align: center;">
  <h4 style="color: white;">&copy <b>crimopedia</b></h4>
</div>
 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html> 