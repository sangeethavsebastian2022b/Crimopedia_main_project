<?php
session_start();
$uid = $_SESSION['users_login'];
$ssid=$_SESSION['ssid'];
$logid=$_SESSION['logid'];

// $cid = $_POST['id'];
include 'connect.php'; 
if (isset($_POST['submit'])) {
    $remark = $_POST['remark'];
    $completiondate = $_POST['completiondate'];
    
$sql= "INSERT INTO `tbl_remark`(`sid`,`coid`,`completiodate`,`remark`) 
        VALUES ('$ssid','$logid','$completiodate','$remark')";
        echo $sql;
$dd = mysqli_query($con,$sql);

//$sqli="UPDATE `tbl_schedule` SET `status`='1' WHERE `sid` = '$sid'";
        
//$dd1 = mysqli_query($con,$sqli);
echo "<script>alert('insertion successfully')</script>";
header("location:counsellordashboard.php");
}

?> 