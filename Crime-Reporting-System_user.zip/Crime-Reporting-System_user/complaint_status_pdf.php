<?php
session_start();
include 'connect.php';
if($_SESSION['user_login'])

   
  $usr = $_SESSION['user_login'];
//if(isset($_SESSION['cid']))
    //$cid=$_SESSION['cid'];
    $sql="SELECT * from `complaint_registration` where u_id='$usr'";

    $result=mysqli_query($con,$sql);
    
//$result=mysqli_query($con,"SELECT c_name,c_crime,c_description,c_status from `complaint_registration` where uid=$usr")or die(mysqli_error($con));

include ('pdf_mc_table.php');
$pdf= new PDF_MC_TABLE();
$pdf-> AddPage();
$pdf-> SetFont('Arial','B',15);
$pdf->Cell(176,5,'Status Details',0,0,'C');
 $pdf->Ln();
 $pdf->Ln();
 $pdf->Ln();
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);
$pdf->Multicell(80,12,'Name :' .$row['c_name'],1);
$pdf->Multicell(80,12,'Crime :' .$row['c_crime'],1);
$pdf->Multicell(80,12,'Description :' .$row['c_description'],1);
$pdf->Multicell(80,12,'Status :' .$row['c_status'],1);

$pdf->Output();

?>