<?php include 'connect.php';
$cid=$_GET['s_id'];
$status=$_GET['status'];
if($status==0)
{
    mysqli_query($con,"UPDATE `counselling_request` SET `status`='Approved' WHERE  req_id='$cid'");
    header("location: counsellingschedule.php");

}
?>