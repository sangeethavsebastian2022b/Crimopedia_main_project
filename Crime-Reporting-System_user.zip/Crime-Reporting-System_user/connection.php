<?php      
    $host = "localhost";  
    $user = "crimopediaadmin";  
    $password = '|#Uc!egYUANG)o3O';  
    $db_name = " id19294394_crime";  
      
    $con = mysqli_connect($host, $user, $password, $db_name);  
    if(mysqli_connect_errno()) {  
        die("Failed to connect with MySQL: ". mysqli_connect_error());  
    }  
?>  