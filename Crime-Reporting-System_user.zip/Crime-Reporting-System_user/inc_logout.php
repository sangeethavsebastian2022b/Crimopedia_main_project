<?php

session_start();
header("location:inchargelogin.php");
session_destroy();

?>