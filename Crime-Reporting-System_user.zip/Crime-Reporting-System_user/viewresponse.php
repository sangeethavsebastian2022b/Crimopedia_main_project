<?php
session_start();
if(isset($_SESSION['users_login'])){
include 'connect.php'; 
$uid = $_SESSION['users_login'];

?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Crimopedia </title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <link rel="stylesheet" href="vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>

li {
 display: inline;
 transition-duration: 0.5s;
}

li:hover {
  cursor: pointer;
}

ul li ul {
  visibility: hidden;
  opacity: 0;
  position: absolute;
  transition: all 0.5s ease;
  margin-top: 1rem;
  left: 0;
  display: none;
}

ul li:hover > ul,
ul li ul:hover {
  visibility: visible;
  opacity: 1;
  display: inline;
}

ul li ul li {
  clear: both;
  width: 100%;
}
</style>
    <script>		
function myFunction() 
{
  
        document.getElementById('btn')
        alert("Blocked!");
        document.getElementById('btn').prop('disabled',true);
}	            
</script>

<script>		
function myFunction1() 
{
  
        document.getElementById('btn')
        alert("UnBlocked!");
        document.getElementById('btn').prop('disabled',true);
}	            
</script>
</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="#">Crimopedia</a>
                <a class="navbar-brand hidden" href="./">F</a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li >
                        <a href="policedashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                    <li >
                        <a href="viewcomplaints.php"> <i class="menu-icon fa fa-folder"></i>View Complaints</a>
                    </li>
                    <li class="active">
                        <a href="pendingcases.php"> <i class="menu-icon fa fa-file"></i> Pending Cases  </a>
                    </li>
                    <li>
                        <a href="approvedcases.php"> <i class="menu-icon fa fa-file"></i>Approved Cases </a>
                    </li>
                    <li>
                        <a href="policerespond.php"> <i class="menu-icon fa fa-file"></i>Response page </a>
                    </li>
                    <li>
                        <a href="viewresponse.php"> <i class="menu-icon fa fa-file"></i>View Response </a>
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                   
                    <nav role="navigation">
  <ul>
    
    <li><a href="#"><i class="menu-icon fa fa-file"></i> Counselling</a>
      <ul class="dropdown">
        <li><a href="policerequest.php"><i class="menu-icon fa fa-file"></i>request Counselling</a></li>
         
         <li><a href="policeviewcounsellingschedule.php"><i class="menu-icon fa fa-file"></i>View counselling schedules</a></li> 
         <li><a href="policecounsellingcomplete.php"><i class="menu-icon fa fa-file"></i>View counselling completion</a></li>    
</ul>
        
      </ul>
    </li>
 
  </ul>
</nav>
                   
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->


    <div id="right-panel" class="right-panel" style="background-image: url('images/324.jpg'); height: 100%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/324.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Response Page</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                           <!-- <div class="card-header">
                                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add"><i class="fa fa-plus"></i>&nbsp; Add</button>
                            </div>-->
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                       
                                    <th scope="col">Complainer Name</th>
                                    <th scope="col">Aadhar number</th>
      <th scope="col">Complaint Report date</th>
      <th scope="col">IPC Section</th>
      <th scope="col">Crime</th>
      <th scope="col">Description</th>
      <th scope="col">Location</th>
      <th scope="col">Incident date</th>
      <th scope="col">Incident time</th>
      <th scope="col">Reason</th>
      <th scope="col">Solution</th>
      <th scope="col">Status</th>
      <th scope="col">Response</th>
  
      
      
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $sql11= "select * from police_officer where login_id = '$uid'";
                                    $qr = mysqli_query($con,$sql11) ;
                                    $row = mysqli_fetch_assoc($qr);
                                    $place = $row['o_policestation'];
                                    //echo "Place-".$place;
$sql="select * from `complaint_registration` JOIN crime_section ON crime_section.crime_id=complaint_registration.type_crime JOIN user_registration on complaint_registration.login_id=user_registration.login_id JOIN tbl_policerespond on tbl_policerespond.cid=complaint_registration.cid where location='$place' and c_status='approved';";

  $result=mysqli_query($con,$sql);
  if($result)
  {
      while($row=mysqli_fetch_assoc($result))
      {
          ?>
          
<tr>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['aadhar_number']; ?></td>
<td><?php echo $row['c_date']; ?></td>
<td><?php echo $row['crime_section']; ?></td>
<td><?php echo $row['crime']; ?></td>
<td><?php echo $row['c_description']; ?></td>
<td><?php echo $row['location']; ?></td>
<td><?php echo $row['incident_date']; ?></td>
<td><?php echo $row['incident_time']; ?></td>
<td><?php echo $row['reason']; ?></td>
<td><?php echo $row['solution']; ?></td>
<td><?php echo $row['c_status']; ?></td>
<td><?php echo $row['response']; ?></td>
<!--<?php if($row['c_status']==0){?>
  <?php
  }
 ?>
 <a href="com_status.php?s_id=<?php echo $row['cid']; ?>&&status=0" >
<input type="submit" value="proceed"></a></td>-->

<!--<td>
<button class="btn btn-dark"><a href="addrespond.php?id=<?php echo $row['cid']; ?>" class="text-light">Respond</a></button>

 <td>-->

<!--
<td>
<button class="btn btn-primary"><a href="policeupdate.php?upid=<?php echo $row['officer_id']; ?>" class="text-light">Edit</a></button></td>

-->       

</tr>
<?php
      }
    
  }
  
  ?>
  <?php
}
  ?>
  
      </tbody>                                  
                                </table>

                            </div>

                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->
       

    <!-- Right Panel -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>


</body>

</html>
