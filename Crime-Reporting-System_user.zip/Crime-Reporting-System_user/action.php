<?php
include('connection.php');
if($_POST['id']){
$id=$_POST['id'];
if($id==0){
	echo "<option>Select City</option>";
}else{
	$sql = mysqli_query($con,"SELECT * FROM `counselling` WHERE counselling_id='$id'");
	while($row = mysqli_fetch_array($sql)){
		echo '<option value="'.$row['coid'].'">'.$row['co_name'].'</option>';
		}
	}
}
?>