<?php 
  include 'connect.php';
  session_start();
  if($_SESSION['users_login']==""){
    header("location:userlogin.php");
  }
  $usr = $_SESSION['users_login'];
  //$us_id=$_GET['id'];
  ?>
  <?php
  include 'connect.php';
  $usr = $_SESSION['users_login'];
  $sql="select *from `user_registration` where login_id='$usr'";
  $result=mysqli_query($con,$sql);
 $row=mysqli_fetch_assoc($result);
 $aadhar_number =$row['aadhar_number'];
  ?>

<!DOCTYPE html>
<html>
  <?php

 include 'connect.php';
 if(isset($_POST['submit']))
 {
   
   $date=date('Y-m-d H:i:s');
   $type_crime=$_POST['type_crime'];
   $c_description=$_POST['c_description'];
   $location=$_POST['location'];
   $reason=$_POST['reason'];
   $description=$_POST['c_description'];
   $incident_date=$_POST['incident_date'];
   $incident_time=$_POST['incident_time'];
   $solution=$_POST['solution'];
   
   
   $sql="INSERT INTO complaint_registration( `c_date`, `type_crime`, `location`, `c_status`,`login_id`,`reason`,`solution`,`incident_date`,`incident_time`,`c_description`) VALUES ('$date','$type_crime','$location','pending','$usr','$reason','$solution','$incident_date','$incident_time','$description')";
   if(mysqli_query($con,$sql))   {
    header('location:userhome.php');

   }
   else{
     echo"delete";
   }

 }

 
 
?> 
<head>
<script>  
    function validate() {  
        var name = document.reg_form.fname;  
          
        if (fname.value.length <= 0) {  
            alert("Name is required");  
            fname.focus();  
            return false;  
        }
        </script>
	<title>Complainer Home Page</title>

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

	<link href="complainer_page.css" rel="stylesheet" type="text/css" media="all" />

<body style="background-size: cover;
    background-image: url(home_bg1.jpeg);
    background-position: center;">
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        
        <li class="active"><a href="Userhome.php">Home</a></li>
      </ul>
     
      <ul class="nav navbar-nav navbar-right">
       
      
        <li><a href="logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
      </ul>
    </div>
  </div>
 </nav>
    
    
<div class="video" style="margin-top: 5%"> 
	<div class="center-container">
		 <div class="bg-agile">
			<br><br>
			<div class="login-form"><p></p><br>
                                    <p><h2> Complaint Form</h2></p><br>	
                                    <form method="post" enctype="multipart/form-data">

                                    <p style="color:#dfdfdf">Aadhar_number</p>
                                    
<input type="text"  name="aadhar_number" placeholder="Aadhar Number" required="" disabled value="<?php echo $aadhar_number ?>">
<p style="color:#dfdfdf">Date</p>
<input type="date"   disabled value="<?php echo date("Y-m-d");?>" name="date">
</br>
</br>
<div class="top-w3-agile" style="color:#dfdfdf">Case
<select class="form-control" name="type_crime" style="width: 310px;">
<option selected disabled value="">Select crime</option>
                        <?php
                        $sel_query =  mysqli_query($con, "SELECT * FROM `crime_section`");
                        while ($r5 =  mysqli_fetch_array($sel_query)) {
                        ?>
                        <option value="<?php echo $r5['crime_id']; ?>"><?php echo $r5['crime']; ?> </option>
                        <?php

                        }
                        ?>
						
				    </select>
				</div>
        <p style="color:#dfdfdf">Incident date (if known)</p><input type="date"  name="incident_date" id="description"  required onchange="Validdescription();" />
<span id="msg15" style="color:red;"></span> 
<p style="color:#dfdfdf">Incident Time (if known)</p><input type="time"  name="incident_time" id="description"  required onchange="Validdescription();" />
<span id="msg15" style="color:red;"></span>
<p style="color:#dfdfdf">Description</p><input type="text"  name="c_description" id="description"  required onchange="Validdescription();" />
<span id="msg15" style="color:red;"></span>
                <p style="color:#dfdfdf">Reason</p><input type="text"  name="reason" id="description"  required onchange="Validdescription();" />
<span id="msg15" style="color:red;"></span>
<p style="color:#dfdfdf">Solution</p><input type="text"  name="solution" id="description"  required onchange="Validdescription();" />

</div>





                
                <div class="top-w3-agile" style="color:#dfdfdf">Location of Crime
                <select class="form-control" name="location" style="width: 310px;">
						<option>Kottayam</option>
						<option>Changanaherry</option>
                        <option>Kottayam West</option>
                        <option>Kuravilangadu</option>
                        <option>Karukachal</option>
                        <option>Pala Town</option>
                        <option>Vaikom</option>
                        <option>Mundakayam</option>
                        <option>Pampady</option>
                        <option>Manimala</option>
                        <option>Erattupetta</option>
                        <option>Kanjirappally</option>
                        <option>Ettumanur</option>
						            <option>Chingavanam</option>
                        <option>Kaduthuruthy</option>
                        <option>Maragattupally</option>
                        <option>Erumely</option>
                        <option>Manarcaudu</option>
                        <option>Vakathanam</option>
                        <option>Kidangoor</option>
                   
				    </select>
			

	
<div>

<center><input type="submit" value="Submit" name="submit" style="color:#dfdfdf" text-color="black"></center>
<style>input:valid {
  background: lightgreen;
}
</style>

</form>
</div>
</div>
</div></div>

			

		
	
<div style="position: relative;
   left: 0;
   bottom: 0;
   width: 100%;
   height: 30px;
   background-color: blue;
   color: white;
   text-align: center;">
  <h4 style="color: white;">&copy <b>crimopedia</b></h4>
</div>
 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>