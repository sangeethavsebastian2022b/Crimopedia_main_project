<!DOCTYPE html>
<html>
  
    
<head>
<title>User Registration</title>

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
<link href="complainer_page.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body>

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><b>Crimopedia</b></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="registration.php">Registration</a></li>
       </ul>
    </div>
  </div>
</nav>
	
<div class="video" style="margin-top: 5%"> 
	<div class="center-container">
		 <div class="bg-agile">
			<br><br>
			<div class="login-form">	
				<form action="regconnection.php" method="post" id="form_name">

        <p style="color:#dfdfdf">Full name</p><input type="text"  name="name"  id="name"  required onchange="Validate();"/>
							
        <span id="msg1" style="color:red;"></span>
          <script>
         
function Validate() 
{
    var val = document.getElementById('name').value;

    if (!val.match(/^[A-Z][A-Za-z]{2,}/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('name').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
          
          <p style="color:#dfdfdf">Email-Id</p><input type="email"  name="email" id="email"  required onchange="Validata();"/>
          <span id="msg5" style="color:red;"></span>
          <script>		
function Validata() 
{
    var val = document.getElementById('email').value;

    if (!val.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) 
    {
        document.getElementById('msg5').innerHTML="Enter a Valid Email";
		
		     document.getElementById('email').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}

		</script>
           
                     <p style="color:#dfdfdf" >Password</p><input type="password" class="form-control" name="password"   id="pwd"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required onchange="Validp();" autocomplete="false"/>
                     <span id="msg6" style="color:red;"></span>
 <script>		
function Validp() 
{
    var val = document.getElementById('password').value;

    if (!val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/)) 
    {
        document.getElementById('msg6').innerHTML="Upper case, Lower case, Special character and Numeric number are required in Password filed";
		
		     document.getElementById('password').value = "";
        return false;
    }
document.getElementById('msg6').innerHTML=" ";
    return true;
}

</script>
<p style="color:#dfdfdf">Aadhar Number</p><input type="text"  name="aadhar_number" minlength="12" maxlength="12" required pattern="[123456789][0-9]{11}" id="aadh" onfocusout="f1()"/>
                    <p style="color:#dfdfdf">Addressline1</p><input type="text"  name="address1"  required="" id="addr1" required onchange="Validname();" />
                    <span id="msg3" style="color:red;"></span>
<script>		
function Validname() 
{
    var val = document.getElementById('addr1').value;

    if (!val.match(/^[A-Z][a-z" "]{2,}/)) 
    {
        document.getElementById('msg3').innerHTML="Start with a Capital letter & Only alphabets are allowed";
		            document.getElementById('addr1').value = "";
        return false;
    }
document.getElementById('msg3').innerHTML=" ";
    return true;
}
</script>
          <p style="color:#dfdfdf">Addressline2</p><input type="text"  name="address2"   id="addr2" required onchange="Validadd2();"/>
          <span id="msg4" style="color:red;"></span>
<script>		
function Validadd2() 
{
    var val = document.getElementById('addr2').value;

    if (!val.match(/^[A-Z][a-z" "]{2,}/)) 
    {
        document.getElementById('msg4').innerHTML="Start with a Capital letter & Only alphabets are allowed";
		            document.getElementById('addr2').value = "";
        return false;
    }
document.getElementById('msg4').innerHTML=" ";
    return true;
}
</script>
					<p style="color:#dfdfdf">Addressline3</p><input type="text"  name="address3"   id="addr3" required onchange="Validadd3();"/>
          <span id="msg8" style="color:red;"></span>
<script>		
function Validadd3() 
{
    var val = document.getElementById('addr3').value;

    if (!val.match(/^[A-Z][a-z" "]{2,}/)) 
    {
        document.getElementById('msg8').innerHTML="Start with a Capital letter & Only alphabets are allowed";
		            document.getElementById('addr3').value = "";
        return false;
    }
document.getElementById('msg8').innerHTML=" ";
    return true;
}
</script>


<div class="top-w3-agile" style="color:#dfdfdf">State
                <select class="form-control" name="state" style="width: 310px;  height: 40px" >
						<option>Kerala</option>
						
                        
                   
				    </select>
				</div>
					
<div class="top-w3-agile" style="color:#dfdfdf">District
                <select class="form-control" name="dist" style="width: 310px;  height: 40px" >
						<option>Thiruvananthapuram</option>
						<option>Kollam</option>
                        <option>Pathanamthitta</option>
                        <option>Alappuzha</option>
                        <option>Kottayam</option>
                        <option>Idukki</option>
                        <option>Ernakulam</option>
                        <option>Thrissur</option>
                        <option>Palakkad</option>
                        <option>Malappuram</option>
                        <option>Kozhikode</option>
                        <option>Wayanad</option>
                        <option>Kannur</option>
						<option>Kasaragod</option>
                        
                   
				    </select>
				</div>
					

					<div class="left-w3-agile">
						<p style="color:#dfdfdf">Gender</p><select class="form-control" name="gender">
							<option>Male</option>
							<option>Female</option>
							<option>Others</option>
						</select>
					</div>
					
					<input type="submit" value="Submit" name="s">
				</form>	
			</div>	
		</div>
	</div>	
</div>

          
</body>
</html>