<?php
session_start();
$uid = $_SESSION['users_login'];
$rid=$_SESSION['rid'];
$logid=$_SESSION['logid'];

// $cid = $_POST['id'];
include 'connect.php'; 
if (isset($_POST['submit'])) {
   // $cid=$_GET['cid'];
   // $coid = $_POST['coid'];
  
    
   // $req_id=$_POST['req_id'];
    $date = $_POST['date'];
    $time = $_POST['time']; 
    $location = $_POST['location'];
$sql= "INSERT INTO `tbl_schedule`(`req_id`,`coid`, `s_date`,`s_time`,`s_location`,`status`) 
        VALUES ('$rid','$logid','$date','$time','$location','0')";
$dd = mysqli_query($con,$sql);
$sqli="UPDATE `counselling_request` SET `status`='1' WHERE `req_id` = '$req_id'";
        
$dd1 = mysqli_query($con,$sqli);
echo "<script>alert('insertion successfully')</script>";
header("location:counsellordashboard.php");
}

?> 