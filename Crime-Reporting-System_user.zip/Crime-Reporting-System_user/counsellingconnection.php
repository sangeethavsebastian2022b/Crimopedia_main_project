<?php
include 'connection.php';

 $co_name = $_POST['co_name'];
 $co_email = $_POST['email'];
 $co_mobile = $_POST['co_mobile'];
 $co_office = $_POST['co_office'];
 $co_city = $_POST['co_city'];
 $co_state = $_POST['co_state'];
 $password = $_POST['password'];
 $co_district=$_POST['co_district'];
 $co_experience=$_POST['co_experience'];
 $co_practice_area=$_POST['counselling_section'];
 

 ?>
<?php
	  $sel1="select * from `users_login` where `email`='$co_email'";
	  $result=mysqli_query($con,$sel1);
	  $num=mysqli_num_rows($result);
	   if($num>0)
		{
	   ?>
	   <script> 
		alert("Username already in exist");
	  </script>
	<?php
			header("location:counselling.php");
		}
		else
		{
	$sql="INSERT INTO `users_login`(`email`, `password`, `role`) VALUES('$co_email','$password','counsellor')";
	$r=mysqli_query($con,$sql);
	if($r){
		$nn = mysqli_insert_id($con);
		$sql2="INSERT INTO `counselling`(`login_id`, `co_name`,  `co_mobile`, `co_office`, `co_city`, `co_state`, `co_district`, `co_experience`, `counselling_id`) VALUES('$nn','$co_name','$co_mobile','$co_office','$co_city','$co_state','$co_district','$co_experience','$co_practice_area')";
		mysqli_query($con,$sql2);
			echo "<script>alert('insertion successfully')</script>";
			header("location:counselling.php");
	}
	
}

	
		
?> 
	