
<?php
include 'connect.php';
 $email = $_POST['email']; $officer_name = $_POST['name'];
 $o_policestation = $_POST['station'];
 $officer_rank = $_POST['rank'];
 $officer_location = $_POST['location'];
 $email = $_POST['email'];
 $password = $_POST['password'];
 $zone=$_POST['zone'];
 $range=$_POST['range'];

	  $sel1="select * from `users_login` where `email`='$email'";
	  $result=mysqli_query($con,$sel1);
	  $num=mysqli_num_rows($result);
	   if($num>0)
		{
	   ?>
	   <script> 
		alert("Username already in exist");
	  </script>
	<?php
		}
		else
		{
	$sql="INSERT INTO `users_login`(`email`, `password`, `role`) VALUES('$email','$password','police')";
	$r=mysqli_query($con,$sql);
	if($r){
		$nn = mysqli_insert_id($con);
		$sql1="INSERT INTO `police_officer`(`login_id`, `officer_name`, `o_policestation`, `officer_rank`, `officer_location`, `zone`, `range`) 
		VALUES('$nn','$officer_name','$o_policestation','$officer_rank','$officer_location','$zone','$range')";
		mysqli_query($con,$sql1);
			echo "<script>alert('insertion successfully')</script>";
			header("location:policeoffinformation.php");
	}
	
}

	
		
?> 
	