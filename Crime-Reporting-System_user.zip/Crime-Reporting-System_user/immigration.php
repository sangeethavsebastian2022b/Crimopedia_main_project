
<?php
session_start();
if(isset($_SESSION['users_login'])){
include 'connect.php'; 
$uid = $_SESSION['users_login'];

?><!DOCTYPE html>
<html>
<head>
	<title>View Lawyer Details</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

 
    

  

</head>
<body>
<?php echo "Place-".$place; ?>

	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><b>Crimopedia </b></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        
       
</ul>
      <ul class="nav navbar-nav navbar-right">
       
        <li><a href="p_logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
      </ul>
      <h3><center>Lawyer Details</center></h>  
    </div>
  </div>
 </nav>
 
<!-- <form style="margin-top: 7%; margin-left: 40%;" method="post">
    <input type="text" name="cid" style="width: 250px; height: 30px; background-color:white; color:grey; margin-top:5px;" placeholder="&nbsp Complaint Id" onfocusout="f1()" required id="ciid">
        <div>
      <input class="btn btn-primary" type="submit" value="Search" name="s2" style="margin-top: 10px; margin-left: 11%;">
        </div>
    </form>-->
<div style="padding:50px;margin-top:5%;">
   <table class="table table-bordered">
    <thead class="thead-dark" style="background-color: black; color: white;">
      <tr>
      <!-- <th scope="col">No:</th> -->
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Office Address</th>
      <th scope="col">City</th>
      <!-- <th scope="col">Status</th> -->
      <th scope="col">State</th>
      <th scope="col">District</th>
      <th scope="col">Experience</th>
      <th scope="col">Practice area</th>
      <th scope="col">Court</th>

      <th scope="col">Action</th>
      
        
      </tr>
    </thead>

<?php
// $sql11= "select * from `add_lawyer` where login_id = '$uid'";
// //echo $sql11;
// $qr = mysqli_query($con,$sql11) ;
// while($row = mysqli_fetch_assoc($qr)){
//     $area = $row['practice_area'];
    //echo "Place-".$place;
    $sql="select * from `add_lawyer`  where practice_area='Immigration'";
    //echo $sql;
    $result=mysqli_query($con,$sql);


if($result)
      while($row=mysqli_fetch_assoc($result)){
        // $i=0;
        // $i++;

    ?> 
    <tbody style="background-color: white; color: black;">
      <tr>
      <!-- <td><?php echo $i ?></td> -->
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['mobile']; ?></td>
<td><?php echo $row['office_address']; ?></td>
<td><?php echo $row['city']; ?></td>
<td><?php echo $row['state']; ?></td>
<td><?php echo $row['district']; ?></td>
<td><?php echo $row['experience']; ?></td>
<td><?php echo $row['practice_area']; ?></td>
<td><?php echo $row['court']; ?></td>
<td>
<button class="btn btn-primary"><a href="policeupdate.php" class="text-light">Book</a></button>

 <td>
<!-- <td><?php echo $row['c_status']; ?></td>
<td><?php if($row['c_status']==0){?>
  <?php
  }
 ?>
 <a href="com_status.php?s_id=<?php echo $row['cid']; ?>&&status=0" >
<input type="submit" value="proceed"></a></td> -->


          
      </tr>
    </tbody>
    
    <?php
    } 
    ?>
  
</table>
 </div>
 <?php }
 else{
   echo "unauthorized accesss";
 }?>

 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>