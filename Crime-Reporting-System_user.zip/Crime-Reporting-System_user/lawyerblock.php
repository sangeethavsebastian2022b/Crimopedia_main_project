<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from add_lawyer where aid='$r_id'";
    $res = mysqli_query($con, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["login_id"]; 
    #echo $pid;

	
	mysqli_query($con,"update `users_login` set status=0 where login_id='$lid'");
	header('location:advocateinfo.php');
?>