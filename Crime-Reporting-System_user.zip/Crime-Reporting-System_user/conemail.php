<?php
include('connect.php');
$meh = $_POST['email'];
$sql ="SELECT * FROM counselling, users_login WHERE  counselling.login_id=users_login.login_id and users_login.login_id=$usr";
$query = $con->query($sql);

while ($res = $query->fetch_assoc()) {
    echo $res['email'];
}