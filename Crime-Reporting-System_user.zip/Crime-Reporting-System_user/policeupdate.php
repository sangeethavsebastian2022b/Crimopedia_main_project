<?php      
    include 'connection.php';
    
    $officer_id=$_GET['upid'];
    $sql="select *from `police_officer` join `users_login` on police_officer.login_id=users_login.login_id where officer_id='$officer_id'";
    $result=mysqli_query($con,$sql);
   $row=mysqli_fetch_assoc($result);
    $officer_name=$row['officer_name'];
    $o_policestation = $row['o_policestation'];
    $officer_rank = $row['officer_rank'];
    $officer_location = $row['officer_location'];
    $officer_email = $row['email'];
    $officer_password = $row['password'];

    if(isset($_POST['s']))
    {
    $officer_id=$_GET['upid']; 
    $officer_name = $_POST['name'];
    $o_policestation = $_POST['station'];
    $officer_rank = $_POST['rank'];
    $officer_location = $_POST['location'];
    $officer_email = $_POST['email'];
    $officer_password = $_POST['password'];
    
   
        mysqli_query($con,"UPDATE `police_officer` join `users_login` on police_officer.login_id=users_login.login_id SET 
        `officer_id`='$officer_id',`officer_name`='$officer_name',`o_policestation`='$o_policestation',`officer_rank`='$officer_rank',`officer_location`='$officer_location',`email`='$officer_email',`password`='$officer_password' where officer_id='$officer_id'");
    
            echo "<script>alert('Updated');</script>";
            header('location: policeoffinformation.php');
     }
  
      
    
 ?>
 
 <!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-image: url('images/224.jpeg'); 
}  
.container {  
    padding: 50px;  
  background-color: white;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style> 
<style> form{
  padding: 150px 170px;
}</style> 
</head>  
<body>  
<form method='post' action="" >  
  
  <div class="container">  
  <center>  <h1>update information</h1> </center>  
  <hr>  
  <div class="modal-header">
 
                          </div>
                      <div class="modal-body">
                     <div class="card-body card-block">
                     <div class="form-group">
                        <label for="company" class=" form-control-label">Officer Name :</label>
                   <input type="text"   class="form-control" name="name"  id="name"  onfocusout="f1()" value=<?php echo $officer_name?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Police station </label>
                    <input type="text"  class="form-control" name="station" id="station"  onfocusout="f1()" value=<?php echo $o_policestation?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Officer rank</label>
                    <input type="text"  class="form-control" name="rank"  id="rank"  onfocusout="f1()" value=<?php echo $officer_rank?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Officer location</label>
                    <input type="text"  class="form-control" name="location" id="location" onfocusout="f1()" value=<?php echo $officer_location?>>
                </div>
                
                
               
                <div class="form-group">
                        <label for="company" class=" form-control-label">Email </label>
                    <input type="email"   class="form-control" name="email" id="email" onfocusout="f1()" value=<?php echo $officer_email?>>
                </div>  
                <div class="form-group">
                       
                     <p style="">Password</p><input type="text"  name="password"   id="pwd"  value=<?php echo $officer_password?>>

                </div>  
            </div>  
                     
                </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-right: 66%">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="s">Update</button>
            </div>
                   
            </div>
                </div>
            
</form>  
</body>  
</html>