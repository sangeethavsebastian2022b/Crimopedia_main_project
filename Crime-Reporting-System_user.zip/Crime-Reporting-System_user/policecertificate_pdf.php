<?php
session_start();
include 'connect.php';
if($_SESSION['users_login'])
if(isset($_POST['viewdetails']))
 {
   $cid=$_POST['cid'];
   $_SESSION['cid']=$cid;
   header("location:complaint_page_pdf.php");
 }
   
  $uid = $_SESSION['users_login'];
  
  $sql11= "select * from police_officer where login_id = '$uid'";
  $qr = mysqli_query($con,$sql11) ;
  $row = mysqli_fetch_assoc($qr);
  $place = $row['o_policestation'];
    $sql="SELECT * FROM complaint_registration JOIN user_registration ON user_registration.login_id=complaint_registration.login_id JOIN counselling_request ON complaint_registration.cid=counselling_request.cid JOIN tbl_schedule ON tbl_schedule.req_id= counselling_request.req_id JOIN tbl_remark on tbl_remark.sid=tbl_schedule.sid JOIN police_officer ON police_officer.login_id=counselling_request.login_id JOIN counselling ON counselling.coid=counselling_request.coid where location='$place' ";
  

     $result=mysqli_query($con,$sql);
    
//$resul t=mysqli_query($con,"SELECT * from `complaint_registration` where uid=$usr")or die(mysqli_error($con));

include ('pdf_mc_table.php');
$pdf= new PDF_MC_TABLE();
$pdf-> AddPage();
$pdf-> SetFont('Arial','B',15);
$pdf->Cell(176,5,'Counselling Completion Cerficate',0,0,'C');
 $pdf->Ln();
 $pdf->Ln();
 $pdf->Ln();
 $pdf->Ln();

$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','B',12);
$pdf->Ln();
 $pdf->Ln();
 $pdf->Ln();
// $pdf->Cell(176,5,'This is to certify that Mr./Mrs./Ms.'.$row['name'],0,0,'B');
$pdf->Cell(200,5,'This is to certify that Mr./Mrs./Ms. '.$row['name'].' has successfully completed ',0,0,'C');
$pdf->Ln();
$pdf->Ln();
$pdf->Cell(190,5,'from . '.$row['s_date'].' to '.$row['completiondate'].' the counselling section.  Refered by ',0,0,'C');
$pdf->Ln();
$pdf->Ln();
$pdf->Cell(155,5,' '.$row['officer_name'].' '.$row['officer_rank'].' '.$row['o_policestation'].' ',0,0,'C');




$pdf->Ln();

 $pdf->Ln();
 $pdf->Ln();
 $pdf->Cell(100,12,'Certified by:  '.$row['co_name'].'',0,0,'C');
 $pdf->Ln();
 $pdf->Cell(100,5,''.$row['co_office'].'',0,0,'C');
 $pdf->Ln();
 $pdf->Cell(90,5,''.$row['co_city'].'',0,0,'C');

// $pdf->Multicell(80,12,'Name :' .$row['name'],1);
//  $pdf->Multicell(80,12,'Gender :' .$row['gender'],1);
//  $pdf->Multicell(80,12,'Address :' .$row['address1']."\n".$row['address2']."\n".$row['address3'],1);
//  //$pdf->Multicell(80,12,'District :' .$row['district'],1);
// // $pdf->Multicell(80,12,'State :' .$row['state'],1);
// // $pdf->Multicell(80,12,'Nation :' .$row['c_nation'],1);
// // $pdf->Multicell(80,12,'Phone :' .$row['c_phone'],1);
// // $pdf->Multicell(80,12,'Email :' .$row['c_email'],1);
// $pdf->Multicell(80,12,'Date :' .$row['c_date'],1);
// $pdf->Multicell(80,12,'Crime :' .$row['type_crime'],1);
//$pdf->Multicell(80,12,'Description :' .$row['c_description'],1);
//$pdf->Multicell(80,12,'Status :' .$row['c_status'],1);
// $pdf->Multicell(80,12,'User id :' .$row['u_id'],1);
// $pdf->Multicell(80,12,'File :' .$row['file'],1);

$pdf->Output();

?>