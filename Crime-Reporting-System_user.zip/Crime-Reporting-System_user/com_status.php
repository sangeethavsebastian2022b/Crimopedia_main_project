<?php include 'connect.php';
$cid=$_GET['s_id'];
$c_status=$_GET['status'];
if($c_status==0)
{
    mysqli_query($con,"UPDATE `complaint_registration` SET `c_status`='Approved' WHERE  cid='$cid'");
    header("location: viewcomplaints.php");

}
?>