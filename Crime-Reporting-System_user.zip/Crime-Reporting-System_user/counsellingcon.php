<?php
include 'connection.php';
if (isset($_POST['counsellingId']) && !empty($_POST['counsellingId'])){
 echo "hello";
    // Fetch state name base on country id
    
    $query = "SELECT * FROM `counselling` WHERE counselling_id = ".$_POST['counsellingId'];
    $result = $con->query($query);
    
    if ($result->num_rows > 0) {
    echo '<option value="">Select counsellor name</option>';
    while ($row = $result->fetch_assoc()) {
    echo '<option value="'.$row['coid'].'">'.$row['co_name'].'</option>';
    }
    } else {
    echo '<option value="">Not Available</option>';
    }
   } 
?>