<?php
include 'connection.php';

 $category = $_POST['category'];
 
	  $sel1="select * from `lawyer_section` where `category`='$category'";
	  $result=mysqli_query($con,$sel1);
	  $num=mysqli_num_rows($result);
	   if($num>0)
		{
	   ?>
	   <script> 
		alert("Section Already Exist");
	  </script>
	<?php
			header("location:lawyersection.php");
		}
		else
		{
	$sql="INSERT INTO `lawyer_section`(`category`) VALUES('$category')";
	//$r=mysqli_query($con,$sql);
	mysqli_query($con,$sql);
			echo "<script>alert('insertion successfully')</script>";
			header("location:lawyersection.php");
	
	
}

	
		
?> 