<?php
 $apiKey="rzp_test_ONOZjRbrcY2YZv";
 include 'connect.php';
 $tid=$_GET['tid'];
  session_start();
  if($_SESSION['users_login']==""){
    header("location:userlogin.php");
  }
  $usr = $_SESSION['users_login'];
 // $sec_id=$_GET['id'];
  
  
 
$id=$_SESSION['users_login'];
$query="SELECT * FROM users_login where login_id ='$id'";
$res = mysqli_query($con,$query);
$r=mysqli_fetch_array($res);

if($r[4]==1)
{

  $query1="SELECT * FROM user_registration where login_id ='$id'";
  $res1 = mysqli_query($con,$query1);
  $r1=mysqli_fetch_array($res1);


?>

          <?php
            
   
    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');  
    $u=$_SESSION['users_login'];
     $l=$_GET['id'];
     $sql = mysqli_query($con, "SELECT * FROM complaint_registration JOIN user_registration ON user_registration.login_id=complaint_registration.login_id 
     JOIN counselling_request ON complaint_registration.cid=counselling_request.cid JOIN tbl_schedule ON tbl_schedule.req_id= counselling_request.req_id JOIN tbl_remark on tbl_remark.sid=tbl_schedule.sid JOIN police_officer ON police_officer.login_id=counselling_request.login_id JOIN counselling ON counselling.coid=counselling_request.coid JOIN tbl_amount ON tbl_amount.coid=counselling.coid 
     JOIN users_login ON users_login.login_id=user_registration.login_id and user_registration.login_id='$usr'");
     $r6 = mysqli_fetch_array($sql);
    
     $amt=$r6['amount'];
       
       
    
    echo $id;
    echo $l;
    $sql1="INSERT INTO tbl_payment_counselling(login_id,amount,status) VALUES ('$usr','$amt','paid')";
    mysqli_query($con,$sql1);
    $pid=mysqli_insert_id($con);
    // if($i=='Unpaid')
    // {
    // $sql = mysqli_query($con, "UPDATE `booking_tbl` SET `pstatus`='Paid' WHERE bk_id='$l' and log_id='$id'");
    if (headers_sent()) {
      ?>
    <script>
      alert("Paid Successfully");
      </script>
    <?php
      die('<script type="text/javascript">window.location.href="bill.php?id='.$usr.'" </script>');
    } else {
      header("location:counsellingbill.php?id=".$usr."&&tid=$tid&&pid=$pid");
      die();
    }   
    }
    
    
      

  
?>
          