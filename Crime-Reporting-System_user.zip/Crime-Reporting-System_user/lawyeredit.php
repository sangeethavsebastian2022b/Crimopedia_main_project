<?php
include 'connection.php';
session_start();
if($_SESSION['users_login']==""){
  header("location:userlogin.php");
}
$usr = $_SESSION['users_login'];

?>
<!DOCTYPE html>
<html>
<head>
	<title>User_Home</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
   table {
    border-collapse: collapse;
    width: 100%;
    color: #000;
  }
  
 td {
    text-align: center;
    padding: 10px;
  }
  th{
       text-align: left;
    padding: 10px;
  }
  
  tr:nth-child(even){background-color:#f2f2f2}
  
  th {
    background-color:rgb(11, 11, 94);
    color: white;
    width:300px;
  }
  
td {
    width: 950px;
    
}
.tdi{
    width:450px;
    
}
  .in{
    text-align: left;
    padding: 10px;
    width: 90%;
  }
  .frm
    {
      position:absolute;
      top:200px;
      left:500px;
      width:50%; 
      border-radius: 10px;
      background-color: white;
     
    }
    .tdi input:focus{
      outline: 6px;
      border-color: rgb(61, 185, 61);
  
  }
.error
{
 font-size:bold;
 color:red;
 text-transform: uppercase;
 text-align: center;
 font-size: 7px;
  
    
}  


.button1 {
    background-color:rgb(129, 30, 30);
    border-radius: 2px;
    border: none;
    color: white;
    padding: 12px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 20px;
    margin: 7px 2px;
    margin-top: 50px;
    cursor: pointer;
    font-family: sans-serif;
    margin-left: 200px;
}

.button2 {
  background-color:rgb(129, 30, 30);
  border-radius: 2px;
  border: none;
  color: white;
  padding: 12px 34px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  margin: 4px 2px;
  cursor: pointer;
  font-family: sans-serif;
}
</style>
  <style>
    body {
    background-size: cover;
    background-image: url(h.jpg);
    background-position: center; 
}

body,
html {
    width: 100%;
    height: 100%;
    font-family: "Lato";
    color: white;
}

h1 {
  font-weight: 700;
  font-size: 5em;
}


.content{
  padding-top: 25%;
  text-align: center;
    text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
                 0px 8px 13px rgba(0,0,0,0.1),
                 0px 18px 23px rgba(0,0,0,0.1);
}

hr {
    width: 250px;
    border-top: 1px solid #f8f8f8;
    border-bottom: 1px solid rgba(0,0,0,0.2);
}
</style>	
     
</head>
<body>
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><b>Crimopedia</b></a>
    </div>
   
      <ul class="nav navbar-nav navbar-right">
      <li><a href="logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
      </ul>
    </div>
  </div>
 </nav>
<div style="padding:50px;">
</div>
<?php 
$query1="SELECT * FROM add_lawyer, users_login WHERE  add_lawyer.login_id=users_login.login_id and users_login.login_id=$usr";
  $res1 = mysqli_query($con,$query1);
  $r=mysqli_fetch_array($res1);
?>
<form action="lawyerprofile.php" method="POST" name="frm" id="form" class="frm" >
<div class="error"><p id="demo"></p></div>
<table width="100%" border="3" style="border-collapse:collapse;">
<tr>
<th><center><strong> Name</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter The First Name" name="name" id="name"autocomplete="off" value="<?php echo $r['name'];?>"></center></td>
</tr>
<tr>
<th><center><strong> Email</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter The Last Name" name="email" id="lname"autocomplete="off" value="<?php echo $r['email'];?>"></center></td>
</tr>
<th><center><strong>office_address</strong></center></th>
<td class="tdi"><center><input type="text" class ="in" id="office_address" name="office_address" autocomplete="off" value="<?php echo $r['office_address'];?>"></center></td>
</tr> 
<tr>
<th><center><strong>City</strong></center></th>
<td class="tdi"><center><input type="text" class ="in" placeholder="Enter The Email Id" id="city" name="city" autocomplete="off" value="<?php echo $r['city'];?>"></center></td>
</tr>
<tr>
<th><center><strong>State</strong></center></th>
<td class="tdi"><center><input type="text" class ="in"placeholder="Enter The Phone Number"id ="state" name="state"autocomplete="off" value="<?php echo $r['state'];?>"></center></td>
</tr>
<tr>
<th><center><strong>District</strong></center></th>
<td class="tdi"><center><input type="text" class ="in"placeholder="Enter The Phone Number"id ="district" name="district"autocomplete="off" value="<?php echo $r['district'];?>"></center></td>
</tr>
<tr>
<th><center><strong>Experience</strong></center></th>
<td class="tdi"><center><input type="text" class ="in"placeholder="Enter The Phone Number"id ="experience" name="experience"autocomplete="off" value="<?php echo $r['experience'];?>"></center></td>
</tr>
<tr>
<th><center><strong>Practice area</strong></center></th>
<td class="tdi"><center><input type="text" class ="in"placeholder="Enter The Phone Number"id ="practice_area" name="practice_area"autocomplete="off" value="<?php echo $r['practice_area'];?>"></center></td>
</tr>
<tr>
<th><center><strong>court</strong></center></th>
<td class="tdi"><center><input type="text" class ="in" placeholder="Enter Your User Name" id="court" name="court"autocomplete="off" value="<?php echo $r['court'];?>"></center></td>
</tr>   
</table>
<button type="submit" name="Click" class="button1">Update</button>
<a href="lawyerprofile.php" class="button2">Cancel</a>
</form>
   </table>



 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>
<?php
if(isset($_POST["Click"]))
{
$name1=$_POST['name'];
$mobile1=$_POST['mobile'];
$office_address=$_POST['office_address'];
$city1=$_POST['city'];
$state1=$_POST['state'];
$district1=$_POST['district'];
$experience1=$_POST['experience'];
$practice_area1=$_POST['practice_area'];
$court1=$_POST['court'];
$sql2="UPDATE `add_lawyer` SET name = '$name1', mobile='$mobile1' ,`office_address`='$office_address1', city = '$city', state='$state1' ,district='$district1',experience='$experience1',practice_area='$practice_area1',court='$court1' WHERE login_id='$login_id'";
$result=mysqli_query($con,$sql2);
if($result)
{
  
    ?>
    <script>
    alert("Profile Updated Successfully");
    </script>
    <?php
    die('<script type="text/javascript">window.location.href="lawyerProfile.php"</script>');
  }
  
else{
?>
<script>
alert("Error Occured");
</script>
<?php
}
}?>
