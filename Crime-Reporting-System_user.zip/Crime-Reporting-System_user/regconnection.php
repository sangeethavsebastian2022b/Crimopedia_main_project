
<?php
	include 'connect.php';
	use PHPMailer\PHPMailer\PHPMailer; 
    use PHPMailer\PHPMailer\Exception;
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $address1 = $_POST['address1'];
        $address2 = $_POST['address2'];
        $address3 = $_POST['address3'];
        $dist = $_POST['dist'];
        $state = $_POST['state'];
        $gender = $_POST['gender'];
		$aadhar_number = $_POST['aadhar_number'];
    
   
	?>
	  <?php
	  $sel1="select * from `users_login` where `email`='$email'";
	  $result=mysqli_query($con,$sel1);
	  $num=mysqli_num_rows($result);
	   if($num>0)
		{
	   ?>
	   <script> 
		alert("Username already in exist");
	  </script>
	<?php
		}
		else
		{
	$sql="INSERT INTO `users_login`(`email`, `password`, `role`,`status`) VALUES('$email','$password','user','1')";
	$r=mysqli_query($con,$sql);
	if($r){
		$nn = mysqli_insert_id($con);
		$sql1="INSERT INTO `user_registration`(`name`, `address1`, `address2`, `address3`, `dist`, `state`, `gender`, `login_id`,`aadhar_number`,`us_id`) 
		VALUES('$name','$address1','$address2','$address3','$dist','$state','$gender', '$nn','$aadhar_number','$us_id')";
		echo $sql;

		mysqli_query($con,$sql1);

		require 'PHPMailer/Exception.php'; 
        require 'PHPMailer/PHPMailer.php'; 
        require 'PHPMailer/SMTP.php'; 
 
$mail = new PHPMailer; 
 
$mail->isSMTP();                      // Set mailer to use SMTP 
$mail->Host = 'smtp.gmail.com';       // Specify main and backup SMTP servers 
$mail->SMTPAuth = true;               // Enable SMTP authentication 
$mail->Username = 'Crimopedia@gmial.com';   // SMTP username 
$mail->Password = 'qudvvouoekmkopdf';   // SMTP password 
$mail->SMTPSecure = 'tls';            // Enable TLS encryption, `ssl` also accepted 
$mail->Port = 587;                    // TCP port to connect to 
// Sender info 
$mail->setFrom('sender@Crimopedia.com', 'Crimopedia'); 
$mail->addReplyTo('reply@Crimopedia.com', 'Crimopedia'); 
// Add a recipient 
$mail->addAddress($email);
//$mail->addCC('cc@example.com'); 
//$mail->addBCC('bcc@example.com'); 
// Set email format to HTML 
$mail->isHTML(true); 
// Mail subject 
$mail->Subject = 'Email from Crimopedia'; 
// Mail body content 
$bodyContent .= '<html>
<head>
<meta charset="utf-8">
</head>

<body background="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4hVvyxHSVWVWGu8Uqq1bOi0x7KAhUG22svA&usqp=CAU" style="background-size: cover;">
    <center>
<h1 style="margin-top: 50px;">Welcome to <b style="color:crimson;">Crimopedia</b></h1>
<p>Hai,</p>
<p> Your Account Created Succefully <br>

<div style="margin-top:30px">
Explore from here--->> <a href="">Crimopedia</a></div>
</center>
</body>
</html>'; 
$mail->Body    = $bodyContent; 
 
// Send email 
$mail->send();
}
header("Location:userlogin.php");
		}

	
		
?> 
<?php
if($sql)
{
	$to =$e;
	$subject="Email Verification";
	#message = "<a href='http://localhost/crime/Crime-Reporting-System_user/regostration/verify.php?vkey=$vkey'>Register";</a>
}


?>
	
   

