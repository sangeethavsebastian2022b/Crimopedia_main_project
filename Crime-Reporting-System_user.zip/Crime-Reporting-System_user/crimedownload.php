<!-- <?php
include "connection.php";
session_start();
if($_SESSION['admin_login']==""){
  header("location:index.php");
}
$usr = $_SESSION['admin_login'];
if(isset($_GET['did']))
{
    $cid=$_GET['did'];
    $stst=$db->prepare("select *from newfiles where cid=$cid");
    $stat->bindParam(1,$did);
    $stat->execute();
    $data=$stat->fetch();
    $
}
?> -->