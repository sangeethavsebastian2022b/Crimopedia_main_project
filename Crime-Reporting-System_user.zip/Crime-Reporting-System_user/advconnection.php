<?php
include 'connection.php';

 $name = $_POST['name'];
 $email = $_POST['email'];
 $mobile = $_POST['mobile'];
 $office_address = $_POST['office_address'];
 $city = $_POST['city'];
 $state = $_POST['state'];
 $password = $_POST['password'];
 $district=$_POST['district'];
 $qualification=$_POST['qualification'];
 $experience=$_POST['experience'];
 $category=$_POST['category'];
 $court=$_POST['court'];

 ?>
<?php
	  $sel1="select * from `users_login` where `email`='$email'";
	  $result=mysqli_query($con,$sel1);
	  $num=mysqli_num_rows($result);
	   if($num>0)
		{
	   ?>
	   <script> 
		alert("Username already in exist");
	  </script>
	<?php
		}
		else
		{
	$sql="INSERT INTO `users_login`(`email`, `password`, `role`,`status`) VALUES('$email','$password','lawyer','1')";
	$r=mysqli_query($con,$sql);
	if($r){
		$nn = mysqli_insert_id($con);
		$sql2="INSERT INTO `add_lawyer`(`login_id`, `a_name`,  `mobile`, `office_address`, `city`, `state`, `district`, `experience`, `sec_id`, `court`,`qualification`) VALUES('$nn','$name','$mobile','$office_address','$city','$state','$district','$experience','$category','$court','$qualification')";
		mysqli_query($con,$sql2);
			echo "<script>alert('insertion successfully')</script>";
			header("location:advocateinfo.php");
	}
	
}

	
		
?> 
	