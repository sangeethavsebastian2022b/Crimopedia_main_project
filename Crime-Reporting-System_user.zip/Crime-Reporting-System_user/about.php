
<!DOCTYPE html>
<html>
<head>
	<title>User_Home</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
  
  <style>
     form {
          padding: 60px 200px
      }
  </style>
  <style>
    body {
    background-size: cover;
    background-image: url(h.jpg);
    background-position: center; 
}

body,
html {
    width: 100%;
    height: 100%;
    font-family: "Lato";
    color: white;
}

h1 {
  font-weight: 700;
  font-size: 5em;
}


.content{
  padding-top: 25%;
  text-align: center;
    text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
                 0px 8px 13px rgba(0,0,0,0.1),
                 0px 18px 23px rgba(0,0,0,0.1);
}

hr {
    width: 250px;
    border-top: 1px solid #f8f8f8;
    border-bottom: 1px solid rgba(0,0,0,0.2);
}
</style>	
     
</head>
<body>
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><b>Crimopedia</b></a>
    </div>
   
  </div>
 </nav>
<div style="padding:50px;">
</div>
<form> 
    <h2> <center>About Us</center></h2>
    <p style="color:#FF0000";><h3>  Crime which is an unlawful act is increasing in our society day by day. With the advancement of technology, criminals are also getting new ways of doing crimes. 
        Crime takes place due to a few common reasons that are money, imbalance mentality, and emotions. After the crime takes place victims need to go through a very complicated and lengthy process for reporting the crime at police station. 
        It’s also a very hectic process for the crime branch to do it manually and maintain the records. So Crimopedia is the solution for all the victims and for the crime department.
        allow victims and witnesses of crime to report incidents to
police 24/7 from any location.</h3> </p>
</form>



 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>