<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from user_registration where us_id='$r_id'";
    $res = mysqli_query($con, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["login_id"]; 
    #echo $pid;

	
	mysqli_query($con,"update `users_login` set status=1 where login_id='$lid'");
	header('location:user.php');
?>