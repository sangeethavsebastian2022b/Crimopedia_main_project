<?php      
    include 'connection.php';
    
    $aid=$_GET['upid'];
    $sql="select *from `add_lawyer` join `users_login` on add_lawyer.login_id=users_login.login_id where aid='$aid'";
    $result=mysqli_query($con,$sql);
    $row=mysqli_fetch_assoc($result);
    $name=$row['name'];
    $mobile= $row['mobile'];
    $office_address = $row['office_address'];
    $city= $row['city'];
    $state = $row['state'];
    $district = $row['district'];
    $experience= $row['experience'];
   // $category = $row['category'];
    $court = $row['court'];

    if(isset($_POST['s']))
    {
    $aid=$_GET['upid']; 
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $office_address = $_POST['office_address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $district = $_POST['district'];
    $experience = $_POST['experience'];
    $practice_area= $_POST['practice_area'];
    $court= $_POST['court'];

    
   
        mysqli_query($con,"UPDATE `add_lawyer` join `users_login` on add_lawyer.login_id=users_login.login_id SET 
        `aid`='$aid',`name`='$name',`mobile`='$mobile',`office_address`='$office_address',`city`='$city',`state`='$state',`district`='$district',`experience`='$experience',`practice_area`='$practice_area',`court`='$court' where aid='$aid'");
    
            echo "<script>alert('Updated');</script>";
            header('location: policeoffinformation.php');
     }
  
      
    
 ?>
 
 <!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-image: url('images/224.jpeg'); 
}  
.container {  
    padding: 50px;  
  background-color: white;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style> 
<style> form{
  padding: 150px 170px;
}</style> 
</head>  
<body>  
<form method='post' action="" >  
  
  <div class="container">  
  <center>  <h1>update information</h1> </center>  
  <hr>  
  <div class="modal-header">
 
                          </div>
                      <div class="modal-body">
                     <div class="card-body card-block">
                     <div class="form-group">
                        <label for="company" class=" form-control-label"> Name :</label>
                   <input type="text"   class="form-control" name="name"  id="name"  onfocusout="f1()" value=<?php echo $name?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">mobile </label>
                    <input type="text"  class="form-control" name="mobile" id="station"  onfocusout="f1()" value=<?php echo $mobile?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Office address</label>
                    <input type="text"  class="form-control" name="office_address"  id="rank"  onfocusout="f1()" value=<?php echo $office_address?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">city</label>
                    <input type="text"  class="form-control" name="city" id="location" onfocusout="f1()" value=<?php echo $city?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">state</label>
                    <input type="text"  class="form-control" name="state" id="station"  onfocusout="f1()" value=<?php echo $state?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Office address</label>
                    <input type="text"  class="form-control" name="office_address"  id="rank"  onfocusout="f1()" value=<?php echo $office_address?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">city</label>
                    <input type="text"  class="form-control" name="city" id="location" onfocusout="f1()" value=<?php echo $city?>>
                </div>
                <div class="form-group">
                <div class="form-group">
                       
                    <!-- <p style="">Password</p><input type="text"  name="password"   id="pwd"  value=<?php echo $officer_password?>>
-->
                </div>  
            </div>  
                     
                </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-right: 66%">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="s">Update</button>
            </div>
                   
            </div>
                </div>
            
</form>  
</body>  
</html>