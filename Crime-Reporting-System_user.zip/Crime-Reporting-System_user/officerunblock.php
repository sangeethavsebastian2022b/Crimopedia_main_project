<?php
	$r_id=$_GET['uid'];
	include('connection.php');

    $query = "select * from police_officer where officer_id='$r_id'";
    $res = mysqli_query($con, $query);
    $r = mysqli_fetch_array($res);
    $lid=$r["login_id"]; 
    #echo $pid;

	
	mysqli_query($con,"update `users_login` set status=1 where login_id='$lid'");
	header('location:policeoffinformation.php');
?>