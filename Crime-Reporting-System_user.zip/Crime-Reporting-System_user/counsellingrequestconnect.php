<?php
session_start();
$uid = $_SESSION['users_login'];
// $cid = $_POST['id'];
include 'connect.php'; 
if (isset($_POST['submit'])) {
    $cid = $_POST['cid'];
    

    $counsellingsec = $_POST['counsellingsec'];
    $counsellor = $_POST['counsellor']; 
$sql= "INSERT INTO `counselling_request`(`login_id`, `cid`,`section`,`coid`) 
        VALUES ('$uid','$cid','$counsellingsec','$counsellor')";
        echo $sql;
$dd = mysqli_query($con,$sql);
echo "<script>alert('insertion successfully')</script>";
header("location:policerequest.php");
}

?> 