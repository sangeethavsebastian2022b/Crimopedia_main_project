<?php
 include 'connection.php';
 session_start();
if($_SESSION['users_login']==""){
  header("location:userlogin.php");
}
$usr = $_SESSION['users_login'];
 ?>
 

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Crime Reporting System </title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <link rel="stylesheet" href="vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <script>		
function myFunction() 
{
  
        document.getElementById('btn')
        alert("Blocked!");
        document.getElementById('btn').prop('disabled',true);
}	            
</script>

<script>		
function myFunction1() 
{
  
        document.getElementById('btn')
        alert("UnBlocked!");
        document.getElementById('btn').prop('disabled',true);
}	            
</script>
</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="#">Crimopedia</a>
                <a class="navbar-brand hidden" href="./">F</a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                    <li>
                        <a href="crimeinformation.php"> <i class="menu-icon fa fa-folder"></i>Crime Information</a>
                    </li>
                    <li>
                        <a href="policeoffinformation.php"> <i class="menu-icon fa fa-file"></i>police officer  </a>
                    </li>
                    <li>
                        <a href="advocateinfo.php"> <i class="menu-icon fa fa-file"></i>Lawyer info </a>
                    </li>
                   <li>
                        <a href="lawyersection.php"> <i class="menu-icon fa fa-file"></i>Lawyer Section </a>
                    </li>
                    <li>
                        <a href="counselling.php"> <i class="menu-icon fa fa-file"></i>Counselling info </a>
                    </li>
                    <li>
                        <a href="counselling_section.php"> <i class="menu-icon fa fa-file"></i>Counselling section </a>
                    </li>
                    
                    <li >
                        <a href="lawyerrequest.php"> <i class="menu-icon fa fa-file"></i>User request </a>
                    </li>
                   <li>
                        <a href="user.php"> <i class="menu-icon fa fa-users"></i>User </a>
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                   <!-- <li >
                        <a href="residentcredential.php"> <i class="menu-icon fa fa-file-o"></i>Resident Credential </a>
                    </li>-->
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>        
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->


    <div id="right-panel" class="right-panel" style="background-image: url('images/224.jpeg'); height: 100%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Lawyer Information</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add"><i class="fa fa-plus"></i>&nbsp; Add</button>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                       
                                    
                                            <th scope="col">Full Name</th>
                                            <th scope="col">Email Address</th>
                                            <th scope="col">Mobile</th>
                                            <th scope="col">Office Address</th>
                                            <th scope="col">State</td>
                                            <th scope="col">District</td>
                                            <th scope="col">City</th>
                                            <th scope="col">Qualification</td>
                                            <th scope="col">Practice Area</td>
                                            <th scope="col">Experience(in year)</td>
                                            
                                            <th scope="col">Court</td>
                                            <th scope="col">Update</td>
                                            <th scope="col">Action</td>
                                            
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
  $sql="select * from `add_lawyer` join `users_login` on add_lawyer.login_id=users_login.login_id JOIN lawyer_section ON add_lawyer.sec_id=lawyer_section.sec_id";
  $result=mysqli_query($con,$sql);
  if($result)
  {
      while($row=mysqli_fetch_assoc($result))
      {
          ?>
          
<tr>

<td><?php echo $row['a_name']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $row['mobile']; ?></td>
<td><?php echo $row['office_address']; ?></td>
<td><?php echo $row['state']; ?></td>
<td><?php echo $row['district']; ?></td>
<td><?php echo $row['city']; ?></td>
<td><?php echo $row['qualification']; ?></td>
<td><?php echo $row['category']; ?></td>
<td><?php echo $row['experience']; ?></td>
<td><?php echo $row['court']; ?></td>

<!-- <td><?php echo $row['password']; ?></td> -->

<td>
<button class="btn btn-primary"><a href="lawyerupdate.php?upid=<?php echo $row['aid']; ?>" class="text-light">Edit</a></button>

 
<?php 

if($row["status"]==1){
?>
                    <td> 
                    <a href="lawyerblock.php?uid=<?php echo $row['aid'];?>">
                    <button class="btn btn-danger" class="text-light" id="btn" value="Block" onclick="myFunction()">Disable</button>
                  </a> 
                    </td>
                    <?php } else {?>
                      <td> 
                    <a href="lawyerunblock.php?uid=<?php echo $row['aid'];?>">
                    <button class="btn btn-primary" class="text-light" id="btn" value="Block" onclick="myFunction1()">Enable</button>
                  </a> 
                    </td><?php }?>

</tr>
<?php
      }
    
  }
  
  ?>
  
  
      </tbody>                                  
                                </table>

                            </div>

                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->
        <div class="modal fade" id="add" tabindex="-1" role="dialog" aria-labelledby="meduimmodalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-md" role="document">
                        <div class="modal-content">
                            <form method="post" action="advconnection.php">
                            <div class="modal-header">
                                <h5 class="modal-title" id="smallmodalLabel">Add Lawyer Information : </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                          </div>
                      <div class="modal-body">
                     <div class="card-body card-block">
                     <div class="form-group">
                        <label for="company" class=" form-control-label"> Name :</label>
                   <input type="text"   class="form-control" name="name" id="name" required onchange="Validate();" autocomplete="false">
                   <span id="msg1" style="color:red;"></span>
          <script>
         
function Validate() 
{
    var val = document.getElementById('name').value;

    if (!val.match(/^[A-Z][A-Za-z]{2,}/)) 
    {
        document.getElementById('msg1').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('name').value = "";
        return false;
    }
document.getElementById('msg1').innerHTML=" ";
    return true;
}
</script>
 
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Email </label>
                    <input type="text"  class="form-control" name="email" id="email" required onchange="Validata();" autocomplete="false"/>
                    <span id="msg11" style="color:red;"></span>
          <script>		
function Validata() 
{
    var val = document.getElementById('email').value;

    if (!val.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) 
    {
        document.getElementById('msg11').innerHTML="Enter a Valid Email";
		
		     document.getElementById('email').value = "";
        return false;
    }
document.getElementById('msg11').innerHTML=" ";
    return true;
}

		</script>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Mobile</label>
                        <input type="tel" id="myform_phone" name="mobile"
                        onsubmit = "return validateForm()"required autocomplete="false" max=10>
      <script type="text/javascript">
    function validateForm() {
        return checkPhone();
    }
    function checkPhone() {
        var phone = document.forms["myForm"]["phone"].value;
        var phoneNum = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/; 
            if(phone.value.match(phoneNum)) {
                return true;
            }
            else {
                document.getElementById("phone").className = document.getElementById("phone").className + " error";
                return false;
            }
        }
</script>
                   
               
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Office address</label>
                    <input type="text"   class="form-control" name="office_address" id="address" required onchange="Validate2();" autocomplete="false">
                    <span id="msg2" style="color:red;"></span>
          <script>
         
function Validate2() 
{
    var val = document.getElementById('address').value;

    if (!val.match(/^[A-Z][A-Za-z]{2,}/)) 
    {
        document.getElementById('msg2').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('address').value = "";
        return false;
    }
document.getElementById('msg2').innerHTML=" ";
    return true;
}
</script>
 
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">City</label>
                    <input type="text"   class="form-control" name="city" id="city" required onchange="Validate3();" autocomplete="false">
                    <span id="msg3" style="color:red;"></span>
          <script>
         
function Validate3() 
{
    var val = document.getElementById('city').value;

    if (!val.match(/^[A-Z][A-Za-z]{2,}/)) 
    {
        document.getElementById('msg3').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('city').value = "";
        return false;
    }
document.getElementById('msg3').innerHTML=" ";
    return true;
}
</script>
 
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label" >State</label>
                        <span id="msg4" style="color:red;"></span>
         
                    <input type="text"   class="form-control" name="state" id="state" required onchange="Validate5();" autocomplete="false">
                    <span id="msg5" style="color:red;"></span>
          <script>
         
function Validate5() 
{
    var val = document.getElementById('state')
    if (!val.match(/^[A-Z][A-Za-z]{2,}/)) 
    {
        document.getElementById('msg5').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('state').value = "";
        return false;
    }
document.getElementById('msg5').innerHTML=" ";
    return true;
}
</script>
 
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">District</label>
                    <input type="text"   class="form-control" name="district" id="district" required onchange="Validate6();" autocomplete="false">
                    <span id="msg6" style="color:red;"></span>
          <script>
         
function Validate6() 
{
    var val = document.getElementById('district').value;

    if (!val.match(/^[A-Z][A-Za-z]{2,}/)) 
    {
        document.getElementById('msg6').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('district').value = "";
        return false;
    }
document.getElementById('msg6').innerHTML=" ";
    return true;
}
</script>
 
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Qualification</label>
                    <input type="text"  class="form-control" name="qualification" id="location" onfocusout="f1()" autocomplete="false" required>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Experience</label>
                    <input type="text"  class="form-control" name="experience" id="location" onfocusout="f1()" autocomplete="false" required>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Practice area</label>
                        <select type="category" name="category" id="category" required>
                        <option selected disabled value="">Select practice area</option>
                        <?php
                        $sel_query =  mysqli_query($con, "select *from lawyer_section");
                        while ($r5 =  mysqli_fetch_array($sel_query)) {
                        ?>
                        <option value="<?php echo $r5['sec_id']; ?>"><?php echo $r5['category']; ?> </option>
                        <?php

                        }
                        ?>
                        
                    </select>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">court</label>
                    <input type="text"  class="form-control" name="court" id="court" required onchange="Validate9();" autocomplete="false">
                    <span id="msg8" style="color:red;"></span>
          <script>
         
function Validate9() 
{
    var val = document.getElementById('court').value;

    if (!val.match(/^[A-Z][A-Za-z]{2,}/)) 
    {
        document.getElementById('msg8').innerHTML="Start with a Capital letter & Only alphabets without space are allowed!!";
		            document.getElementById('court').value = "";
        return false;
    }
document.getElementById('msg8').innerHTML=" ";
    return true;
}
</script>
 
                </div>
                 <div class="form-group">
                        <label for="company" class=" form-control-label">Password : </label>
                     <p style="color:#dfdfdf">Password</p><input type="password"  name="password"   id="pwd"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required  onchange="Validp();"/>
                     <span id="msg12" style="color:red;"></span>
 <script>		
function Validp() 
{
    var val = document.getElementById('pwd').value;

    if (!val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/)) 
    {
        document.getElementById('msg12').innerHTML="Upper case, Lower case, Special character and Numeric number are required in Password filed";
		
		     document.getElementById('pwd').value = "";
        return false;
    }
document.getElementById('msg12').innerHTML=" ";
    return true;
}

</script>
                </div>  
            </div>
                </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-right: 66%">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="s">Confirm</button>
            </div>
                   
            </div>
                </div>
           
                </form>
                 </div>
                    </div>
                        </div>
                        <!-- MODAL END -->
                        <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="meduimmodalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-md" role="document">
                        <div class="modal-content">
                            
                 </div>
                    </div>
                        </div>
    </div><!-- /#right-panel -->

    <!-- Right Panel -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>


</body>

</html>
