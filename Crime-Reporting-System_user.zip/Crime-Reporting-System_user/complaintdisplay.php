<?php 
include "connect.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Official Login</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
</head>

<body style="background-size: cover;
    background-image: url(home_bg1.jpeg);
    background-position: center;">
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="home.php"><b>Home</b></a>
      <table class="table">
  <thead>
    <tr>
      <th scope="col">No:</th>
      <th scope="col">Name</th>
      <th scope="col">gender</th>
      <th scope="col">Addressline1</th>
      <th scope="col">Addressline2</th>
      <th scope="col">Addressline3</th>
      <th scope="col">District</th>
      <th scope="col">State</th>
      <th scope="col">Nation</th>
      <th scope="col">phone number</th>
      <th scope="col">Email</th>
      <th scope="col">Date</th>
      <th scope="col">Crime</th>
      <th scope="col">Description</th>
      <th scope="col">Operation</th>

    </tr>
  </thead>
  <tbody>


  <?php
  $sql="select * from `complaint_registration`";
  $result=mysqli_query($con,$sql);
  if($result)
  {
      while($row=mysqli_fetch_assoc($result))
      {
          $cid=$row['cid'];
          $c_name=$row['c_name'];
          $c_gender=$row['c_gender'];
          $c_address1=$row['c_address1'];
          $c_address2=$row['c_address2'];
          $c_address3=$row['c_address3'];
          $c_district=$row['c_district'];
   $c_state=$row['c_state'];
   $c_nation=$row['c_nation'];
   $c_phone=$row['c_phone'];
   $c_email=$row['c_email'];
   $c_date=$row['c_date'];
   $c_crime=$row['c_crime'];
   $c_description=$row['c_description'];
   $c_status=$row['c_status'];
echo '
<tr>
<th scope="row">'.$cid.'</th>
<td>'.$c_name.'</td>
<td>'.$c_gender.'</td>
<td>'.$c_address1.'</td>
<td>'.$c_address2.'</td>
<td>'.$c_address3.'</td>
<td>'.$c_district.'</td>
<td>'.$c_state.'</td>
<td>'.$c_nation.'</td>
<td>'.$c_phone.'</td>
<td>'.$c_email.'</td>
<td>'.$c_crime.'</td>
<td>'.$c_description.'</td>
<td>'.$c_status.'</td>
<td>
   <button class="btn btn-primary" ><a href="update.php" class="text-dark" >update</a></button>
   <button class="btn btn-danger"><a href="delete.php? deleteid='.$cid.'"></a>delete</button>
</td>
</tr>';
      }
    
  }
  
  
  
  ?>

  
  </tbody>
</table>
    </div>
</body>
</html>