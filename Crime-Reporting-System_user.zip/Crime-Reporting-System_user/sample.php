<?php 
  include 'connect.php';
  session_start();
  @$iid = $_GET['sid'];
  if($_SESSION['users_login']==""){
    header("location:userlogin.php");
  }
  $usr = $_SESSION['users_login'];
  ?>
  
<!DOCTYPE html>
<html>
  <?php

 include 'connect.php';
 if(isset($_POST['submit']))
 {
   
   $date=date('Y-m-d H:i:s');
   $type_crime=$_POST['type_crime'];
   $c_description=$_POST['description'];
   $location=$_POST['location'];
   
   $sql="INSERT INTO complaint_registration( `c_date`, `type_crime`, `c_description`,`location`, `c_status`, `u_id`) VALUES ('$date','$type_crime','$c_description','$location','pending','$usr')";
   if(mysqli_query($con,$sql))   {
    header('location:complainer_page.php');

   }
   else{
     echo"delete";
   }

 }

 
 
?> 
<head>
<script>  
    function validate() {  
        var name = document.reg_form.fname;  
          
        if (fname.value.length <= 0) {  
            alert("Name is required");  
            fname.focus();  
            return false;  
        }
        </script>
	<title>Complainer Home Page</title>

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

	<link href="complainer_page.css" rel="stylesheet" type="text/css" media="all" />

<body style="background-size: cover;
    background-image: url(home_bg1.jpeg);
    background-position: center;">
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        
        <li class="active"><a href="Userhome.php">Home</a></li>
      </ul>
     
      <ul class="nav navbar-nav navbar-right">
       
      
        <li><a href="logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></li>
      </ul>
    </div>
  </div>
 </nav>
    
    
<div class="video" style="margin-top: 5%"> 
	<div class="center-container">
		 <div class="bg-agile">
			<br><br>
			<div class="login-form"><p></p><br>
                                    <p><h2> Counselling Requesting form</h2></p><br>	
                                    <form method="post" enctype="multipart/form-data">
                                    <p style="color:#dfdfdf">Couselling</p>
                                    <?php if($iid==0 ){ ?>
                                  
                        <select name="counselling_section" id="counselling_section" onchange = "location = this.value;">
                        <option selected disabled value="">Select area</option>
                        <?php
                        $sel_query =  mysqli_query($con, "select * from counselling_section");
                        while ($r5 =  mysqli_fetch_array($sel_query)) {
                        ?>
                        <option value="policerequest.php?sid=<?php echo $r5['counselling_id']; ?>"><?php echo $r5['counselling_section']; ?> </option>
                        <?php  } ?>
                    
                    </select>
                
                                    <p style="color:#dfdfdf">Cousellor name</p>
                                    <?php }else{ ?> 
                                    <select type="name" name="co_name" id="co_name" onchange="change_phoneno();" >
                    <option selected disabled value="">choose name</option> 
                    <?php
                        $sel_query =  mysqli_query($con, "select *from counselling where counselling_id='$iid'");
                        while ($r5 =  mysqli_fetch_array($sel_query)) {
                        ?>
                        <option value="<?php echo $r5['coid']; ?>"><?php echo $r5['co_name']; ?> </option>
                        <?php  } ?>
                  </select>
                  <?php } ?>
                  <div class="error" id="demo2"></div>
                </td>
                </tr>
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

                                        
<p style="color:#dfdfdf">Date</p>
<input type="date"   disabled value="<?php echo date("Y-m-d");?>" name="date">
<p style="color:#dfdfdf">Description</p>
<input type="text"  name="" id="description"  required onchange="Validdescription();" />
<span id="msg15" style="color:red;"></span>
<script>		
function Validdescription() 
{
    var val = document.getElementById('description').value;

    if (!val.match(/^[A-Z][a-z" "]{3,}$/)) 
    {
        document.getElementById('msg15').innerHTML="Start with a Capital letter & Only alphabets are allowed";
		            document.getElementById('description').value = "";
        return false;
    }
document.getElementById('msg15').innerHTML=" ";
    return true;
}
</script>
                <div class="top-w3-agile" style="color:#dfdfdf">Location 
                <select class="form-control" name="location">
						<option>Kottayam</option>
						<option>Changanaherry</option>
                        <option>Kottayam West</option>
                        <option>Kuravilangadu</option>
                        <option>Karukachal</option>
                        <option>Pala Town</option>
                        <option>Vaikom</option>
                        <option>Mundakayam</option>
                        <option>Pampady</option>
                        <option>Manimala</option>
                        <option>Erattupetta</option>
                        <option>Kanjirappally</option>
                        <option>Ettumanur</option>
						<option>Chingavanam</option>
                        <option>Kaduthuruthy</option>
                        <option>Maragattupally</option>
                        <option>Erumely</option>
                        <option>Manarcaudu</option>
                        <option>Vakathanam</option>
                        <option>Kidangoor</option>
                   
				    </select>
				</div>



<input type="submit" value="Submit" name="submit">

</form>
                                   
  
                                  
      

</div>
</div>
</div></div>

			

		
	
<div style="position: relative;
   left: 0;
   bottom: 0;
   width: 100%;
   height: 30px;
   background-color: blue;
   color: white;
   text-align: center;">
  <h4 style="color: white;">&copy <b>crimopedia</b></h4>
</div>
 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
 
</body>
</html>