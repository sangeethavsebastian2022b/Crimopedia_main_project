<?php
include 'connect.php';
session_start();
if($_SESSION['users_login']==""){
  header("location:userlogin.php");
}
$usr = $_SESSION['users_login'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>User_Home</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
  <style>
    body {
    background-size: cover;
    background-image: url(h.jpg);
    background-position: center; 
}

body,
html {
    width: 100%;
    height: 100%;
    font-family: "Lato";
    color: white;
}

h1 {
  font-weight: 700;
  font-size: 5em;
}


.content{
  padding-top: 25%;
  text-align: center;
    text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
                 0px 8px 13px rgba(0,0,0,0.1),
                 0px 18px 23px rgba(0,0,0,0.1);
}

hr {
    width: 250px;
    border-top: 1px solid #f8f8f8;
    border-bottom: 1px solid rgba(0,0,0,0.2);
}
</style>	
<style>
.dropbtn {
  background-color: solid #f8f9f9;
  color: #696969;
  padding: 14px;
  font-size: 15px;
  border: none;
  cursor: pointer;
  
}

.dropbtn:hover, .dropbtn:focus {
  background-color: #white;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto; 
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown a:hover {background-color: #ddd;}

.show {display: block;}
</style>
<style>
.dropbtn1 {
  background-color: solid #f8f9f9;
  color: #696969;
  padding: 14px;
  font-size: 15px;
  border: none;
  cursor: pointer;
  
}

.dropbtn1:hover, .dropbtn1:focus {
  background-color: #white;
}

.dropdown1 {
  position: relative;
  display: inline-block;
}

.dropdown-content1 {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto; 
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content1 a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown1 a:hover {background-color: #ddd;}

.show1 {display: block;}
</style> 
<style>
.dropbtn2 {
  background-color: solid #f8f9f9;
  color: #696969;
  padding: 14px;
  font-size: 15px;
  border: none;
  cursor: pointer;
  
}

.dropbtn2:hover, .dropbtn1:focus {
  background-color: #white;
}

.dropdown2 {
  position: relative;
  display: inline-block;
}

.dropdown-content2 {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto; 
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content2 a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown2 a:hover {background-color: #ddd;}

.show2 {display: block;}
</style>  
</head>
<body>
	<nav  class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href=""><b>Crimopedia</b></a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
      <div class="dropdown2">
  <button onclick="myFunction2()" class="dropbtn2">Complaint</button>
  <div id="myDropdown2" class="dropdown-content2">
    <a href="complainer_page.php">Add Complaint</a>
    <a href="complaint_page_pdf.php">First Information Report</a>
    <a href="complaint_status.php">Complaint_Status</a>
    
    </div>
</div>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
</ul>
<ul>
<div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
      <div class="dropdown2">
  
        
       
        <div class="dropdown">
  <button onclick="myFunction()" class="dropbtn">Legal Support</button>
  <div id="myDropdown" class="dropdown-content">
  <a href="lawyerconsultation.php">Lawyer Consultation</a>
  <a href="intellectual.php">Schedules</a>
    <!--<a href="intellectual.php">Intellectual property Lawyer</a>
    <a href="publicinterest.php">Public Interest Lawyer</a>
    <a href="tax.php">Tax Lawyer</a>
    <a href="corporate.php">Corporate Lawyer</a>
    <a href="immigration.php">Immigration Lawyer</a>
    <a href="criminal">Criminal Lawyer</a>
    <a href="civil">Civil Right Lawyer</a>
    <a href="family">Family Lawyer</a>
    <a href="environmental">Environmental Lawyer</a>
    <a href="estateplanning">Estateplanning Lawyer</a>-->
  </div>

</div>
</ul>
<ul>
 <div class="dropdown1">
  <button onclick="myFunction1()" class="dropbtn1">Counselling</button>
  <div id="myDropdown1" class="dropdown-content1">
    <a href="userviewcounsellingschedule.php">schedules</a>
    <a href="counsellingpaymentgateway.php">Completion Certificate</a>
    </div>
</div>
</ul>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction1() {
  document.getElementById("myDropdown1").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn1')) {
    var dropdowns = document.getElementsByClassName("dropdown-content1");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show1')) {
        openDropdown.classList.remove('show1');
      }
    }
  }
}
</script>
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction2() {
  document.getElementById("myDropdown2").classList.toggle("show2");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn2')) {
    var dropdowns = document.getElementsByClassName("dropdown-content2");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show2')) {
        openDropdown.classList.remove('show2');
      }
    }
  }
}
</script>
 <ul class="nav navbar-nav navbar-right">
       
     <?php
   $sql=mysqli_query($con,"SELECT * FROM `user_registration` where login_id='$usr'");
   $row = mysqli_fetch_array($sql);
?> <ul><li><a><?php echo $row['name'] ?></span></a></li></ul>
       <ul><a href="logout.php">Logout &nbsp <i class="fa fa-sign-out" aria-hidden="true"></i></a></ul>
      </ul>
    </div>
  </div>
 </nav>
<div style="padding:50px;">
</div>




 <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.js"></script>
 <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>
</html>