<?php      
    include 'connection.php';
    $u_id=$_GET['id'];
    $sql="select *from `user_registration` where u_id='$u_id'";
    $result=mysqli_query($con,$sql);
   $row=mysqli_fetch_assoc($result);
   $name =$row['name'];
   $email = $row['email'];
   $password = $row['password'];
   $address1 = $row['address1'];
   $address2 = $row['address2'];
   $address3 = $row['address3'];
   $dist = $row['dist'];
   $state = $row['state'];
   $gender = $row['gender'];
   
    if(isset($_POST['update']))
    {
    $u_id=$_GET['id'];  
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $address1 = $_POST['address1'];
        $address2 = $_POST['address2'];
        $address3 = $_POST['address3'];
        $dist = $_POST['dist'];
        $state = $_POST['state'];
        $gender = $_POST['gender'];

        mysqli_query($con,"UPDATE `user_registration` SET 
        `u_id`='$u_id',`name`='$name',`email`='$email',`password`='$password',`address1`='$address1',`address2`='$address2',`address3`='$address3',`dist`='$dist',`state`='$state',`gender`='$gender' where u_id='$u_id'");
    
            echo "<script>alert('Updated');</script>";
            header('location: user.php');
     }
    
    
?>  

 <!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-image: url('images/224.jpeg');  
}  
.container {  
    padding: 50px;  
  background-color: white;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style>
<style>
  form{
    padding: 160px 180px;
  }
</style>  
</head>  
<body>  
<form method='post' action="" >  
  
  <div class="container">  
  <center>  <h1>update information</h1> </center>  
  <hr>  
  <p style="">Full Name</p><input type="text"  name="name"   id="name1" onfocusout="f1()" value=<?php echo $name?>>
					<p style="">Email-Id</p><input type="text"  name="email"  id="email1" onfocusout="f1()"value=<?php echo $email?>>
 <p style="">Password</p><input type="text"  name="password"   id="pwd"  value=<?php echo $password?>>

                    <p style="">Addressline1</p><input type="text"  name="address1"   id="addr1" onfocusout="f1()"value=<?php echo $address1?>>
          <p style="">Addressline2</p><input type="text"  name="address2"  id="addr2" onfocusout="f1()"value=<?php echo $address2?>>
					<p style="">Addressline3</p><input type="text"  name="address3"  id="addr3" onfocusout="f1()"value=<?php echo $address3?>>
					<p style="">District</p><input type="text"  name="dist"  id="dist" onfocusout="f1()"value=<?php echo $dist?>>
					<p style="">State</p><input type="text"  name="state"  id="state" onfocusout="f1()"value=<?php echo $state?>>
					

					<div class="left-w3-agile">
						<p style="">Gender</p><select class="form-control" name="gender" value=<?php echo $gender?>>
							<option>Male</option>
							<option>Female</option>
							<option>Others</option>
						</select>
					</div>
          <input type="submit" value="Submit" name="update"> 
</form>  
</body>  
</html>