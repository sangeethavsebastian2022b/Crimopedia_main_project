<?php
include 'connection.php';

 $counselling_section = $_POST['counselling_section'];
 
 

 ?>
<?php
	  $sel1="select * from `counselling_section` where `counselling_section`='$counselling_section'";
	  $result=mysqli_query($con,$sel1);
	  $num=mysqli_num_rows($result);
	   if($num>0)
		{
	   ?>
	   <script> 
		alert("Section Already Exist");
	  </script>
	<?php
			header("location:counselling_section.php");
		}
		else
		{
	$sql="INSERT INTO `counselling_section`(`counselling_section`) VALUES('$counselling_section')";
	//$r=mysqli_query($con,$sql);
	mysqli_query($con,$sql);
			echo "<script>alert('insertion successfully')</script>";
			header("location:counselling_section.php");
	
	
}

	
		
?> 