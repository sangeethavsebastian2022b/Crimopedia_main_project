<?php      
     session_start();
    include 'connect.php';
    
    if (isset($_POST['email']) && isset($_POST['password']))
    {
    $officer_email = $_POST['email'];  
    $officer_password = $_POST['password'];  
      
        //to prevent from mysqli injection  
        $officer_email = stripcslashes($officer_email);  
        $officer_password = stripcslashes($officer_password);  
        $officer_email = mysqli_real_escape_string($con, $officer_email);  
        $officer_password = mysqli_real_escape_string($con, $officer_password);  
      
        $sql = "select *from police_officer where officer_email = '$officer_email' and officer_password = '$officer_password'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        
        $count = mysqli_num_rows($result);  
          
        if($count == 1){  
          header("location:policehome.php");
          $_SESSION['admin'] = $row['officer_id'];
 
        }  
        else{  
            echo "<h1> Login failed. Invalid username or password.</h1>";  
        }
    }
