<?php
session_start();
if(isset($_SESSION['users_login'])){
include 'connect.php'; 
$uid = $_SESSION['users_login'];
$usr = $_SESSION['users_login'];
$request_id=@$_GET['id'];
$_SESSION['logid']=$request_id;


?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->
<?php

 include 'connect.php';
 if(isset($_POST['submit']))
 {
    $logid=$_SESSION['logid'];
  $lawyersection=$_POST['lawyersection'];
   $name=$_POST['lawyer'];
  
   
   $sql="INSERT INTO tbl_assign(`request_id`, `l_section`, `lawyer_name`) VALUES ('$logid','$lawyersection','$name')";
    echo $sql;
   if(mysqli_query($con,$sql))   {
    header('location:dashboard.php');

   }
   else{
     echo"delete";
   }

 }

 
 
?> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Crime Reporting System </title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <link rel="stylesheet" href="vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <style>
   table {
    border-collapse: collapse;
    width: 100%;
    color: #3C92B0;
  }
  
 td {
    text-align: center;
    padding: 10px;
  }
  th{
       text-align: left;
    padding: 20px;
  }
  
  tr:nth-child(odd){background-color:#f2f2f2}
  
  th {
    background-color:rgb(94, 11, 80);
    color: white;
    width:300px;
  }
  
td {
    width: 950px;
    
}
.tdi{
    width:450px;
    
}
  .in{
    text-align: left;
    padding: 10px;
    width: 90%;
  }
  .frm
    {
      position:absolute;
      top:200px;
      left:500px;
      width:50%; 
      border-radius: 10px;
      background-color: white;
     
    }
    .tdi input:focus{
      outline: 6px;
      border-color: rgb(61, 185, 61);
  
  }
.error
{
 font-size:bold;
 color:red;
 text-transform: uppercase;
 text-align: center;
 font-size: 7px;
  
    
}  


.button1 {
    background-color:rgb(129, 30, 30);
    border-radius: 2px;
    border: none;
    color: white;
    padding: 12px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 20px;
    margin: 7px 2px;
    margin-top: 50px;
    cursor: pointer;
    font-family: sans-serif;
    margin-left: 200px;
}

.button2 {
  background-color:rgb(129, 30, 30);
  border-radius: 2px;
  border: none;
  color: white;
  padding: 12px 34px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 20px;
  margin: 4px 2px;
  cursor: pointer;
  font-family: sans-serif;
}
</style>
    <script>		
function myFunction() 
{
  
        document.getElementById('btn')
        alert("Blocked!");
        document.getElementById('btn').prop('disabled',true);
}	            
</script>

<script>		
function myFunction1() 
{
  
        document.getElementById('btn')
        alert("UnBlocked!");
        document.getElementById('btn').prop('disabled',true);
}	            
</script>
</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="#">Crimopedia</a>
                <a class="navbar-brand hidden" href="./">F</a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                    <li>
                        <a href="crimeinformation.php"> <i class="menu-icon fa fa-folder"></i>Crime Information</a>
                    </li>
                    <li>
                        <a href="policeoffinformation.php"> <i class="menu-icon fa fa-file"></i>police officer  </a>
                    </li>
                    <li>
                        <a href="advocateinfo.php"> <i class="menu-icon fa fa-file"></i>Lawyer info </a>
                    </li>
                   <li>
                        <a href="lawyersection.php"> <i class="menu-icon fa fa-file"></i>Lawyer Section </a>
                    </li>
                    <li>
                        <a href="counselling.php"> <i class="menu-icon fa fa-file"></i>Counselling info </a>
                    </li>
                    <li>
                        <a href="counselling_section.php"> <i class="menu-icon fa fa-file"></i>Counselling section </a>
                    </li>
                    
                    <li >
                        <a href="lawyerrequest.php"> <i class="menu-icon fa fa-file"></i>User request </a>
                    </li>
                   <li>
                        <a href="user.php"> <i class="menu-icon fa fa-users"></i>User </a>
                    </li>
                    <h3 class="menu-title"></h3><!-- /.menu-title -->
                   <!-- <li >
                        <a href="residentcredential.php"> <i class="menu-icon fa fa-file-o"></i>Resident Credential </a>
                    </li>-->
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav> </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->


    <div id="right-panel" class="right-panel" style="background-image: url('images/324.jpg'); height: 100%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/324.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#"><i class="fa fa-user"></i> My Profile</a>

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Lawyer Assign Form</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                   <!-- <div class="col-md-12">
                        <div class="card">
                           
                            <div class="card-body">-->
                                
                            <form  method="POST" name="frm" id="form" class="frm" >
<div class="error"><p id="demo"></p></div>
<table width="100%" border="3" style="border-collapse:collapse;">
<tr>
<th><center><strong>lawyer Section</strong></center></th>
<td class="tdi"><select name="lawyersection" class="add_lawyer" style="width: 380px; height: 45px">
<option value="0">Select Section</option>
<?php
include('connection.php');
$sql = mysqli_query($con,"SELECT * FROM lawyer_section");
while($row=mysqli_fetch_array($sql))
{
echo '<option value="'.$row['sec_id'].'">'.$row['category'].'</option>';
} ?>
</td>
</select>
</tr>
<tr>
<th><center><strong> Name</strong></center></th>
<td class="tdi"><select name="lawyer" class="lawyername" style="width: 380px; height: 45px">
<option>Select Name</option>

</td>
</select>
<?php 
$query1="SELECT * FROM add_lawyer, users_login WHERE  add_lawyer.login_id=users_login.login_id and users_login.login_id=$usr";
  $res1 = mysqli_query($con,$query1);
  $r=mysqli_fetch_array($res1);
?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js">
</script>
<script type="text/javascript">
$(document).ready(function()
{
$(".add_lawyer").change(function()
{
var sec_id=$(this).val();
var post_id = 'id='+ sec_id;

$.ajax
({
type: "POST",
url: "action1.php",
data: post_id,
cache: false,
success: function(cities)
{
$(".lawyername").html(cities);
} 
});

});
});
</script>
</tr>

 
<?php 
$id=$_SESSION['users_login'];
$query5 ="SELECT * FROM police_officer where login_id ='$id'";  
$res = mysqli_query($con,$query5);
$r=mysqli_fetch_array($res);
?>
<?php 
$id=$_SESSION['users_login'];
$query6 ="SELECT * FROM user_registration where login_id ='$id'";  
$res1 = mysqli_query($con,$query6);
$ri=mysqli_fetch_array($res1);
?>

<!--
<tr>
<th><center><strong> Police Officer name</strong></center></th>
<td class="tdi"><center><input type="text"  class ="in" placeholder="Enter The Officer  Name" name="email" id="lname" value="<?php echo $r['officer_name'];?>"></center></td>
</tr>
<th><center><strong>Police Station</strong></center></th>
<td class="tdi"><center><input type="text" class ="in" id="address" placeholder="Enter Policestation" name="office_address" autocomplete="off" value="<?php echo $r['o_policestation'];?>"></center></td>
</tr> -->
</table>
<!--<a href="counsellingrequesting.php" class="button1" >Request</a>-->
<!--<input type="submit" value=submit name="submit">-->

<input type="text" name="login_id" value="<?php echo $id; ?>"hidden /> 
<input type="text" name="cid" value="<?php echo $cid; ?>"hidden /> 

<center><input type="submit" value="Submit" name="submit"></center>
</form>

   </table>   

          


                  

                            </div>

                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->
       <!-- /#right-panel -->

    <!-- Right Panel -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>
<?php
}
?>

</body>

</html>


