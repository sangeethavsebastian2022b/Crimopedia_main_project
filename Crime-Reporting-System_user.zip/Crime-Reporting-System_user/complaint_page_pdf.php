<?php
session_start();
include 'connect.php';
if($_SESSION['users_login'])
if(isset($_POST['viewdetails']))
 {
   $cid=$_POST['cid'];
   $_SESSION['cid']=$cid;
   header("location:complaint_page_pdf.php");
 }
   
  $usr = $_SESSION['users_login'];
//if(isset($_SESSION['cid']))
    //$cid=$_SESSION['cid'];
    $sql="SELECT  * from `complaint_registration` JOIN crime_section ON crime_section.crime_id=complaint_registration.type_crime JOIN user_registration on complaint_registration.login_id=user_registration.login_id where complaint_registration.login_id=user_registration.login_id and user_registration.login_id='$usr' ";
  

    $result=mysqli_query($con,$sql);
    
//$result=mysqli_query($con,"SELECT * from `complaint_registration` where uid=$usr")or die(mysqli_error($con));

include ('pdf_mc_table.php');
$pdf= new PDF_MC_TABLE();
$pdf-> AddPage();
$pdf-> SetFont('Arial','B',15);
$pdf->Cell(176,5,'First Information Report',0,0,'C');
 $pdf->Ln();
 $pdf->Ln();
 $pdf->Ln();
$row=mysqli_fetch_array($result);
$pdf->SetFont('Arial','',12);
$pdf->Multicell(80,12,'Name :' .$row['name'],1);
$pdf->Multicell(80,12,'Aadhar Number :' .$row['aadhar_number'],1);
 $pdf->Multicell(80,12,'Gender :' .$row['gender'],1);
 $pdf->Multicell(80,12,'Address :' .$row['address1']."\n".$row['address2']."\n".$row['address3'],1);
 //$pdf->Multicell(80,12,'District :' .$row['district'],1);
// $pdf->Multicell(80,12,'State :' .$row['state'],1);
// $pdf->Multicell(80,12,'Nation :' .$row['c_nation'],1);
// $pdf->Multicell(80,12,'Phone :' .$row['c_phone'],1);
// $pdf->Multicell(80,12,'Email :' .$row['c_email'],1);
$pdf->Multicell(80,12,'Date:' .$row['c_date'],1);
$pdf->Multicell(80,12,'IPC section :' .$row['crime_section'],1);
$pdf->Multicell(80,12,'Crime:' .$row['crime'],1);
$pdf->Multicell(80,12,'Description :' .$row['c_description'],1);
 $pdf->Multicell(80,12,'Location :' .$row['location'],1);
 $pdf->Multicell(80,12,'incident_date :' .$row['incident_date'],1);
 $pdf->Multicell(80,12,'incident_time :' .$row['incident_time'],1);
 $pdf->Multicell(80,12,'Reason :' .$row['reason'],1);
 $pdf->Multicell(80,12,'Solution :' .$row['solution'],1);
// $pdf->Multicell(80,12,'File :' .$row['file'],1);

$pdf->Output();

?>