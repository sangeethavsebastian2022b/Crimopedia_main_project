<?php
include('connection.php');
if($_POST['id']){
$id=$_POST['id'];
if($id==0){
	echo "<option>Select lawyer</option>";
}else{
	$sql = mysqli_query($con,"SELECT * FROM `add_lawyer` WHERE sec_id='$id'");
	while($row = mysqli_fetch_array($sql)){
		echo '<option value="'.$row['aid'].'">'.$row['name'].'</option>';
		}
	}
}
?>