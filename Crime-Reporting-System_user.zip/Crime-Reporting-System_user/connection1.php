<?php
include 'connection.php';

if (isset($_POST['update'])) {
    if (isset($_POST['name']) && isset($_POST['email']) &&
        isset($_POST['address1']) && isset($_POST['address2']) &&
        isset($_POST['address3']) && isset($_POST['dist']) && 
        isset($_POST['state']) && isset($_POST['password']) && 
         isset($_POST['gender'])&&isset($_POST['aadhar_number'])  )  {
        $u_id=$_POST['u_id'];  
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $address1 = $_POST['address1'];
        $address2 = $_POST['address2'];
        $address3 = $_POST['address3'];
        $dist = $_POST['dist'];
        $state = $_POST['state'];
        $gender = $_POST['gender'];
        $aadhar_number = $_POST['aadhar_number'];

        $sql="UPDATE `user_registration` set 'u_id'='$u_id','name'='$name','email'='$email','password'='$password','address1'='$address1','address2'='$address2','address3'='$address3','dist'='$dist','state'='$state','gender'='$gender','aadhar_number'='$aadhar_number";
        $result=mysqli_query($con,$sql);
        if($result)
        {
            header('location:user.php');

        }
        else{
            echo "not";
        }
         }
        }

        if(isset($_GET['updateid']))
        {
            $u_id=$_GET['updateid'];

            $sql="SELECT *from `user_registration` where 'u_id'=$u_id";

            $result=mysqli_query($con,$sql);
            if($result)
            {
                
      while($row=mysqli_fetch_assoc($result))
      {
          $u_id=$row['u_id'];
          $name=$row['name'];
          $email=$row['email'];
          $password=$row['password'];
          $address1=$row['address1'];
          $address2=$row['address2'];
          $address3=$row['address3'];
          $dist=$row['dist'];
          $state=$row['state'];
          $mobno=$row['mobno'];
          $gender=$row['gender'];
 
            }
        }
    }
       
?>